				<?php
				if( manifesto_get_theme_options('clapat_manifesto_portfolio_navigation_order') == 'backward' ){
					previous_post_link( 'manifesto_portfolio' );
				} else {
					next_post_link( 'manifesto_portfolio' );
				}
				?>
