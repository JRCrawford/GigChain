<?php

if( !isset( $manifesto_default_theme_options ) ){

	$manifesto_default_theme_options = array();

	// General Settings
	$manifesto_default_theme_options['clapat_manifesto_enable_ajax'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_enable_smooth_scrolling'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_enable_magic_cursor'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_primary_color'] ='#8c6144';
	$manifesto_default_theme_options['clapat_manifesto_enable_preloader'] = 1;
	$manifesto_default_theme_options['clapat_manifesto_preloader_intro'] = esc_html__( 'Loading', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_preloader_hover_line'] = esc_html__( 'Loading', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_preloader_text'] = esc_html__( 'Please wait, content is loading', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_uppercase_titles'] = 1;
	$manifesto_default_theme_options['clapat_manifesto_default_page_bknd_type'] = 'light-content';
	$manifesto_default_theme_options['clapat_manifesto_enable_page_title_as_hero'] = 1;
	
	// Header Settings
	$manifesto_default_theme_options['clapat_manifesto_logo'] = esc_url( get_template_directory_uri() . '/images/logo.png' );
	$manifesto_default_theme_options['clapat_manifesto_logo_light'] = esc_url( get_template_directory_uri() . '/images/logo-white.png' );
	$manifesto_default_theme_options['clapat_manifesto_enable_fullscreen_menu'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_header_menu_type'] = 'classic-burger-lines';
	$manifesto_default_theme_options['clapat_manifesto_menu_btn_caption'] = esc_html__( 'Menu', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_menu_background_color'] = '#0c0c0c';
	$manifesto_default_theme_options['clapat_manifesto_menu_background_type'] = 'invert-header';
	
	// Footer Settings
	$manifesto_default_theme_options['clapat_manifesto_enable_back_to_top'] = 1;
	$manifesto_default_theme_options['clapat_manifesto_back_to_top_caption'] = esc_html__( 'Back Top', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_footer_copyright'] = wp_kses( __('2023 © <a class="link" target="_blank" href="https://www.clapat-themes.com/">ClaPat</a>. All rights reserved.', 'manifesto'), 'manifesto_allowed_html' );
	$manifesto_default_theme_options['clapat_manifesto_footer_social_links_prefix'] = esc_html__( 'Follow Us', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_social_links_icons'] = 0;
	global $manifesto_social_links;
	$social_network_ids = array_keys( $manifesto_social_links );
	for( $idx = 1; $idx <= MANIFESTO_MAX_SOCIAL_LINKS; $idx++ ){

		$manifesto_default_theme_options['clapat_manifesto_footer_social_' . $idx] = manifesto_social_network_default( $idx );
		$manifesto_default_theme_options['clapat_manifesto_footer_social_url_' . $idx] = manifesto_social_network_url_default( $idx );
	}
	
	// Portfolio Settings
	$manifesto_default_theme_options['clapat_core_portfolio_custom_slug'] = '';
	$manifesto_default_theme_options['clapat_manifesto_portfolio_nav_autotrigger'] = 1;
	$manifesto_default_theme_options['clapat_manifesto_portfolio_autoscroll_hero'] = 1;
	$manifesto_default_theme_options['clapat_manifesto_view_project_caption'] = esc_html__('VIEW', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_open_project_caption'] = esc_html__('OPEN', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_portfolio_filter_all_caption'] = esc_html__('All', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_portfolio_show_filters_caption'] = esc_html__( 'Filters', 'manifesto' );
	$manifesto_default_theme_options['clapat_manifesto_portfolio_next_caption_first_line'] = esc_html__('Next', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_portfolio_next_caption_second_line'] = esc_html__('Project', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_showcase_scroll_drag_caption'] = esc_html__('Scroll or Drag', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_portfolio_share_social_networks_caption'] = esc_html__('Share Project:', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_portfolio_share_social_networks'] = 'facebook,twitter,pinterest';
	$manifesto_default_theme_options['clapat_manifesto_portfolio_navigation_order'] = 'forward';
	
	// Showcase Grid Settings
	$manifesto_default_theme_options['clapat_manifesto_showcase_grid_view_list_caption'] = esc_html__('Lists View', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_showcase_grid_view_grid_caption'] = esc_html__('Grid View', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_showcase_grid_shuffle_grid_caption'] = esc_html__('Shuffle Grid', 'manifesto');
									
	// Blog Settings
	$manifesto_default_theme_options['clapat_manifesto_blog_navigation_type'] = 'blog-nav-classic';
	$manifesto_default_theme_options['clapat_manifesto_blog_excerpt_type'] = 'blog-excerpt-none';
	$manifesto_default_theme_options['clapat_manifesto_blog_excerpt_length'] = 35;
	$manifesto_default_theme_options['clapat_manifesto_blog_next_post_caption'] = esc_html__('Next', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_prev_post_caption'] = esc_html__('Prev', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_read_more_caption'] = esc_html__('Read Article', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_no_posts_caption'] = esc_html__('No more posts', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_prev_posts_caption'] = esc_html__('Prev', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_next_posts_caption'] = esc_html__('Next', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_default_title'] = esc_html__('Blog', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_blog_scroll_effect_type'] = 'clapat-blog-effect-scroll-none';
	
	// Map Settings
	$manifesto_default_theme_options['clapat_manifesto_map_address'] = esc_html__('775 New York Ave, Brooklyn, Kings, New York 11203', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_map_marker'] = esc_url( get_template_directory_uri() . '/images/marker.png');
	$manifesto_default_theme_options['clapat_manifesto_map_zoom'] = 16;
	$manifesto_default_theme_options['clapat_manifesto_map_company_name'] = esc_html__('manifesto', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_map_company_info'] = esc_html__('Here we are. Come to drink a coffee!', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_map_type'] = 'satellite';
	$manifesto_default_theme_options['clapat_manifesto_map_api_key'] = '';
	
	// Error Page
	$manifesto_default_theme_options['clapat_manifesto_error_title'] = esc_html__('404', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_error_info'] = esc_html__('The page you are looking for could not be found.', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_error_back_button'] = esc_html__('Home Page', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_error_back_button_hover_caption'] = esc_html__('Go Back', 'manifesto');
	$manifesto_default_theme_options['clapat_manifesto_error_back_button_url'] = esc_url( get_home_url() );
	$manifesto_default_theme_options['clapat_manifesto_error_page_bknd_type'] = 'light-content';
	
	// Shop
	$manifesto_default_theme_options['clapat_manifesto_shop_enable_custom_grid'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_sticky_shop_product_caption'] = 0;
	$manifesto_default_theme_options['clapat_manifesto_shop_product_page_bknd_type'] = 'light-content';
	$manifesto_default_theme_options['clapat_manifesto_shop_product_page_bknd_color'] = '#0c0c0c';
}

if( !class_exists('Clapat\Manifesto\Metaboxes\Meta_Boxes') ){

	$manifesto_default_meta_options = array (
									"manifesto-opt-page-bknd-color-code" => "#0c0c0c",
									"manifesto-opt-page-bknd-color" => "light-content",
									"manifesto-opt-page-enable-hero" => "",
									"manifesto-opt-page-hero-img" => "",
									"manifesto-opt-page-video" => false,
									"manifesto-opt-page-video-webm" => "",
									"manifesto-opt-page-video-mp4" => "",
									"manifesto-opt-page-hero-caption-title" => "",
									"manifesto-opt-page-hero-caption-subtitle" => "",
									"manifesto-opt-page-hero-subtitle-left-padding" => "subtitle-no-padding",
									"manifesto-opt-page-hero-info-text" => "",
									"manifesto-opt-page-hero-scroll-caption" => esc_html__('Scroll to navigate', 'manifesto'),
									"manifesto-opt-page-hero-padding-bottom" => "enable-padding-bottom",
									"manifesto-opt-page-hero-parallax-caption" => "parallax-scroll-caption",
									"manifesto-opt-page-hero-caption-align" => "text-align-left",
									"manifesto-opt-page-hero-caption-width" => "content-full-width",
									"manifesto-opt-page-navigation-hover-caption" => esc_html__('Next Page', 'manifesto'),
									"manifesto-opt-page-navigation-caption-title" => "",
									"manifesto-opt-page-navigation-caption-subtitle" => "",
									"manifesto-opt-page-navigation-next-page" => "", 
									"manifesto-opt-page-portfolio-filter-category" => "",
									"manifesto-opt-page-portfolio-grid-layout" => "parallax-grid",
									"manifesto-opt-page-portfolio-thumb-to-fullscreen" => "webgl-fitthumbs",
									"manifesto-opt-page-portfolio-thumb-to-fullscreen-webgl-type" => "fx-one",
									"manifesto-opt-page-portfolio-grid-content-position" => "after",									
									"manifesto-opt-page-portfolio-archive-caption" => esc_html__('View Archive', 'manifesto'),
									"manifesto-opt-page-portfolio-archive-page" => "",
									"manifesto-opt-page-portfolio-grid-layout-type" => "layout-one",
									"manifesto-opt-page-portfolio-grid-enable-list-view" => true,
									"manifesto-opt-page-portfolio-grid-enable-shuffle-grid" => true,
									"manifesto-opt-page-portfolio-carousel-enable-preview" => true,
									"manifesto-opt-page-portfolio-carousel-enable-parallax" => true,
									"manifesto-opt-page-portfolio-gallery-enable-preview" => true,
									"manifesto-opt-page-portfolio-gallery-enable-filters" => true,
									"manifesto-opt-page-portfolio-gallery-enable-tilt" => true,
									"manifesto-opt-page-portfolio-gallery-prev-page-caption" => esc_html__('Close Archive', 'manifesto'),
									"manifesto-opt-page-portfolio-gallery-prev-page" => "",
									"manifesto-opt-page-portfolio-slider-rotate-caption" => false,
									"manifesto-opt-blog-bknd-color-code" => "#0c0c0c",
									"manifesto-opt-blog-bknd-color" => "light-content",
									"manifesto-opt-blog-caption-alignment" => "text-align-left",
									"manifesto-opt-portfolio-bknd-color-code" => "#0c0c0c",
									"manifesto-opt-portfolio-bknd-color" => "light-content",
									"manifesto-opt-portfolio-project-year" => date("Y"),
									"manifesto-opt-portfolio-hero-img" => "",
									"manifesto-opt-portfolio-video" => false,
									"manifesto-opt-portfolio-video-webm" => "",
									"manifesto-opt-portfolio-video-mp4" => "",
									"manifesto-opt-portfolio-hero-caption-title" => "",
									"manifesto-opt-portfolio-hero-parallax-caption" => "parallax-scroll-caption",
									"manifesto-opt-portfolio-hero-scroll-caption" => "",
									"manifesto-opt-portfolio-thumb-gallery-offset" => "0",
									"manifesto-opt-portfolio-thumb-gallery-scale" => "has-scale-large",
									"manifesto-opt-portfolio-gallery-enable-parallax" => true,
								);
}

?>
