	<?php if( manifesto_get_theme_options('clapat_manifesto_enable_preloader') ){ ?>
		<!-- Preloader -->
		<div class="preloader-wrap" data-centerLine="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_preloader_hover_line') ); ?>">
			<div class="outer">
				<div class="inner">
					<div class="trackbar">
						<div class="preloader-intro">
							<span><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_preloader_intro'), 'manifesto_allowed_html' ); ?></span>
						</div>
						<div class="loadbar"></div>
						<div class="percentage-wrapper"><div class="percentage" id="precent"></div></div>
					</div>
                    
					<div class="percentage-intro"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_preloader_text'), 'manifesto_allowed_html' ); ?></div>
				</div>
			</div>
		</div>
		<!--/Preloader -->
	<?php } ?>