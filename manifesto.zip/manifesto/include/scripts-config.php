<?php
/**
 * Created by Clapat.
 * Date: 22/07/23
 * Time: 7:26 AM
 */

if ( ! function_exists( 'manifesto_load_scripts' ) ){

	function manifesto_load_scripts() {

		// Force load Elementor styles on non-Elementor pages if AJAX page transitions are turned on
		if ( class_exists( '\Elementor\Frontend' ) && !manifesto_post_is_built_with_elementor() && manifesto_get_theme_options( "clapat_manifesto_enable_ajax" ) ) {

			\Elementor\Frontend::instance()->enqueue_styles();
		}

		// Enqueue css files
		wp_enqueue_style( 'manifesto-content', get_template_directory_uri() . '/css/content.css' );

		wp_enqueue_style( 'manifesto-showcase', get_template_directory_uri() . '/css/showcase.css' );

		wp_enqueue_style( 'manifesto-portfolio', get_template_directory_uri() . '/css/portfolio.css' );

		wp_enqueue_style( 'manifesto-blog', get_template_directory_uri() . '/css/blog.css' );

		wp_enqueue_style( 'manifesto-shortcodes', get_template_directory_uri() . '/css/shortcodes.css' );

		wp_enqueue_style( 'manifesto-assets', get_template_directory_uri() . '/css/assets.css' );
		
		wp_enqueue_style( 'manifesto-shop', get_template_directory_uri() . '/css/shop.css' );
		
		wp_enqueue_style( 'manifesto-style-wp', get_template_directory_uri() . '/css/style-wp.css' );
		
		wp_enqueue_style( 'manifesto-page-builders', get_template_directory_uri() . '/css/page-builders.css' );

		wp_enqueue_style( 'manifesto-theme', get_stylesheet_uri(), array('manifesto-content', 'manifesto-showcase', 'manifesto-portfolio', 'manifesto-blog', 'manifesto-shortcodes', 'manifesto-assets', 'manifesto-style-wp', 'manifesto-page-builders') );

		$manifesto_typography_css = manifesto_typography_css();
		if( empty( !$manifesto_typography_css ) ){
			
			wp_add_inline_style( 'manifesto-theme', $manifesto_typography_css );
		}
		
		if ( class_exists( '\Elementor\Plugin' ) ) {

			wp_enqueue_style( 'elementor-icons-fa-brands' ); // FontAwesome 5 Brands from Elementor
			wp_enqueue_style( 'elementor-icons-fa-solid' ); // FontAwesome 5 Solid from Elementor
		}

		wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/all.min.css' );

		// enqueue standard font style
		$manifesto_main_font_url  = '';
		/*
		Translators: If there are characters in your language that are not supported
		by chosen font(s), translate this to 'off'. Do not translate into your own language.
		 */
		if ( 'off' !== _x( 'on', 'Google font: on or off', 'manifesto') ) {
			$manifesto_main_font_url = add_query_arg( 'family', urlencode( 'Poppins:300,400,500,600,700' ), "//fonts.googleapis.com/css" );
			$manifesto_secondary_font_url = add_query_arg( array( 'family' => urlencode( 'Six Caps' ),
																'display' => 'swap' ), "//fonts.googleapis.com/css" );
		}
		wp_enqueue_style( 'manifesto-main-font', $manifesto_main_font_url, array(), '1.0.0' );
		wp_enqueue_style( 'manifesto-secondary-font', $manifesto_secondary_font_url, array(), '1.0.0' );

		// Force load Elementor scripts on non-Elementor pages if AJAX page transitions are turned on
		if ( class_exists( '\Elementor\Frontend' ) && !manifesto_post_is_built_with_elementor() && manifesto_get_theme_options( "clapat_manifesto_enable_ajax" ) ) {

			\Elementor\Frontend::instance()->enqueue_scripts();
		}

		// enqueue scripts
		if ( is_singular() ) wp_enqueue_script( 'comment-reply' );

			// Register scripts
			wp_enqueue_script(
            'modernizr',
            get_template_directory_uri() . '/core/js/modernizr.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
            'jquery-flexnav',
            get_template_directory_uri() . '/core/js/jquery.flexnav.min.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
            'jquery-waitforimages',
            get_template_directory_uri() . '/core/js/jquery.waitforimages.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
            'jquery-justifiedgallery',
            get_template_directory_uri() . '/core/js/jquery.justifiedGallery.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script( 'imagesloaded' );

		wp_enqueue_script(
            'three',
            get_template_directory_uri() . '/core/js/three.min.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
            'clapatwebgl',
            get_template_directory_uri() . '/core/js/clapatwebgl.js',
            array('jquery'),
            false,
            true
		);
		
		wp_enqueue_script(
            'clapatslider',
            get_template_directory_uri() . '/core/js/clapatslider.min.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
			'gsap',
			get_template_directory_uri() . '/core/js/gsap.min.js',
			array('jquery'),
			false,
			true
		);
		
		wp_enqueue_script(
            'scroll-trigger',
            get_template_directory_uri() . '/core/js/scrolltrigger.min.js',
            array('jquery'),
            false,
            true
		);

		wp_enqueue_script(
			'gsap-flip',
			get_template_directory_uri() . '/core/js/flip.min.js',
			array('jquery'),
			false,
			true
		);

		wp_enqueue_script(
			'js-socials',
			get_template_directory_uri() . '/core/js/jssocials.min.js',
			array('jquery'),
			false,
			true
		);

		wp_enqueue_script(
			'grid-to-fullscreen',
			get_template_directory_uri() . '/core/js/gridtofullscreen.min.js',
			array('jquery'),
			false,
			true
		);

		wp_enqueue_script(
			'smooth-scrollbar',
			get_template_directory_uri() . '/core/js/smooth-scrollbar.min.js',
			array('jquery'),
			false,
			true
		);

		wp_enqueue_script(
			'manifesto-common',
			get_template_directory_uri() . '/core/js/common.js',
			array('jquery'),
			false,
			true
		);
		
		wp_enqueue_script(
			'manifesto-contact',
			get_template_directory_uri() . '/core/js/contact.js',
			array('jquery'),
			false,
			true
		);
		
		wp_enqueue_script(
			'manifesto-scripts',
			get_template_directory_uri() . '/js/scripts.js',
			array('jquery'),
			false,
			true
		);

		wp_localize_script( 'manifesto-common',
						'ClapatThemeOptions',
						array( 	"share_social_network_list" => manifesto_get_theme_options('clapat_manifesto_portfolio_share_social_networks') )
						);
					
		wp_localize_script( 'manifesto-scripts',
                    'ClapatManifestoThemeOptions',
                    array( 	"enable_preloader" 	=> manifesto_get_theme_options('clapat_manifesto_enable_preloader') )
					);

		wp_localize_script( 'manifesto-contact',
							'ClapatMapOptions',
							array(  "map_marker_image"	=> esc_js( esc_url ( manifesto_get_theme_options("clapat_manifesto_map_marker") ) ),
									"map_address"		=> manifesto_get_theme_options('clapat_manifesto_map_address'),
									"map_zoom"			=> manifesto_get_theme_options('clapat_manifesto_map_zoom'),
									"marker_title"		=> manifesto_get_theme_options('clapat_manifesto_map_company_name'),
									"marker_text"		=> manifesto_get_theme_options('clapat_manifesto_map_company_info'),
									"map_type" 			=> manifesto_get_theme_options('clapat_manifesto_map_type'),
									"map_api_key"		=> manifesto_get_theme_options('clapat_manifesto_map_api_key') ) );

	}

}

add_action('wp_enqueue_scripts', 'manifesto_load_scripts');

if ( ! function_exists( 'manifesto_admin_load_scripts' ) ){

    function manifesto_admin_load_scripts() {

		// enqueue standard font style
		$manifesto_main_font_url  = '';
		/*
		Translators: If there are characters in your language that are not supported
		by chosen font(s), translate this to 'off'. Do not translate into your own language.
		 */
		if ( 'off' !== _x( 'on', 'Google font: on or off', 'manifesto') ) {
			$manifesto_main_font_url = add_query_arg( 'family', urlencode( 'Poppins:300,400,600,700' ), "//fonts.googleapis.com/css" );
		}
		wp_enqueue_style( 'manifesto-main-font', $manifesto_main_font_url, array(), '1.0.0' );
	}
}
add_action('admin_enqueue_scripts', 'manifesto_admin_load_scripts');

if ( ! function_exists( 'manifesto_typography_css' ) ){

	function manifesto_typography_css() {
		
		$manifesto_typography_css = '';
		
		// If custom fonts plugin is installed
		if ( class_exists( 'Bsf_Custom_Fonts_Render' ) ){
			
			$arr_custom_fonts = array();
			
			// if custom fonts plugin is installed
			$bsf_instance = Bsf_Custom_Fonts_Render::get_instance();
			
			if( method_exists( $bsf_instance, 'get_existing_font_posts' ) ){

				$all_fonts = $bsf_instance->get_existing_font_posts();

				if ( empty( $all_fonts ) || ! is_array( $all_fonts ) ) {
					
					return;
				}
				
				foreach ( $all_fonts as $font => $id ) {
					
					$font_family    = get_the_title( $id );
					$font_data      = get_post_meta( $id, 'fonts-data', true );

					if ( ! empty( $font_data['variations'] ) ) {
						
						foreach ( $font_data['variations'] as $variation ) {
							
							$font_label = $font_family;
							
							$font_weight = "";
							if( !empty( $variation['font_weight'] ) ){
								
								$font_weight = $variation['font_weight'];
							}
							
							$font_style = "";
							if( !empty( $variation['font_style'] ) ){
								
								$font_style = $variation['font_style'];
							}
							
							$arr_custom_fonts[ $id.$variation['id'] ] = array( 'name' => $font_family, 'weight' => $font_weight,  'style' => $font_style );
						}
					}
					else{
						
						$arr_custom_fonts[ $id ] = array( 'name' => $font_family );
					}
				}
			}
			else {
				
				// Get the custom fonts installed
				$font_terms = get_terms(
								Bsf_Custom_Fonts_Taxonomy::$register_taxonomy_slug,
								array(
									'hide_empty' => false,
								)
							);
							
				if ( ! empty( $font_terms ) ) {
					
					foreach ( $font_terms as $term ) {
						
						$font_props = Bsf_Custom_Fonts_Taxonomy::get_font_links( $term->term_id );
						foreach ( $font_props as $font_prop_id => $font_prop_value  ) {
							
							if ( strpos( $font_prop_id , 'weight' ) !== false ) {
															
								$arr_custom_fonts[ $term->term_id.$font_prop_id ] = array( 'name' => $term->name, 'weight' => $font_prop_value );
							}
						}
					}
				}
			}
			
			// Portfolio primary font title
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_primary_font_title' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_primary_font_title' ) ){
						
						$manifesto_typography_css .= '  .primary-font-title, .slide-title, .hero-title, .next-hero-title, article .post-title, .blog-numbers, .page-numbers, .post-prev-caption, .post-next-caption, .team-member, .slide-hero-title, .preloader-intro, .preloader-intro span, .accordion.bigger-acc dt span {';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Portfolio secondary font title
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_secondary_font_title' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_secondary_font_title' ) ){
						
						$manifesto_typography_css .= '  .secondary-font-title, em, .percentage {';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Portfolio subtitle
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_main_subtitle' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_main_subtitle' ) ){
						
						$manifesto_typography_css .= ' .hero-subtitle, .next-hero-subtitle, .slide-subtitle, .slide-hero-subtitle, .slide-cat, .slide-date, .percentage-intro { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Headings
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_headings' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_headings' ) ){
						
						$manifesto_typography_css .= ' h1, h2, h3, h4, h5, h6 { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Paragraph
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_paragraph' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_paragraph' ) ){
						
						$manifesto_typography_css .= ' p,  #ball p, .accordion .accordion-content, .hero-text, #filters li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Body
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_body' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_body' ) ){
						
						$manifesto_typography_css .= ' html, body { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Inputs
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_inputs' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_inputs' ) ){
						
						$manifesto_typography_css .= ' input, textarea, input[type="submit"] { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Fullscreen Menu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_fullscreen_menu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_fullscreen_menu' ) ){
						
						$manifesto_typography_css .= ' @media all and (min-width: 1025px) { .fullscreen-menu .flexnav li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Fullscreen Submenu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_fullscreen_submenu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_fullscreen_submenu' ) ){
						
						$manifesto_typography_css .= ' @media all and (min-width: 1025px) { .fullscreen-menu .flexnav li ul li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Classic Menu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_classic_menu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_classic_menu' ) ){
						
						$manifesto_typography_css .= ' @media all and (min-width: 1025px) { .classic-menu .flexnav li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Classic Submenu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_classic_submenu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_classic_submenu' ) ){
						
						$manifesto_typography_css .= ' @media all and (min-width: 1025px) { .classic-menu .flexnav li ul li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Responsive Menu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_responsive_menu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_responsive_menu' ) ){
						
						$manifesto_typography_css .= ' @media all and (max-width: 1024px) { .flexnav li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
			
			// Responsive Submenu
			if( manifesto_get_theme_options( 'clapat_manifesto_typography_responsive_submenu' ) ){
				
				// Find the font
				foreach( $arr_custom_fonts as $custom_font_id => $custom_font_props ){
					
					if( $custom_font_id == manifesto_get_theme_options( 'clapat_manifesto_typography_responsive_submenu' ) ){
						
						$manifesto_typography_css .= ' @media all and (max-width: 1024px) { .flexnav li ul li a { ';
						$manifesto_typography_css .= 'font-family: "' . $custom_font_props['name'] . '"; ';
						if( !empty( $custom_font_props['weight'] ) ){
							
							$manifesto_typography_css .= 'font-weight: ' . $custom_font_props['weight'] . '; ';
						}
						if( !empty( $custom_font_props['style'] ) ){
							
							$manifesto_typography_css .= 'font-style: ' . $custom_font_props['style'] . '; ';
						}
						$manifesto_typography_css .= '} ';
						$manifesto_typography_css .= '}';
						break;
					}
				}
			}
		}
		
		return $manifesto_typography_css;
	}
}