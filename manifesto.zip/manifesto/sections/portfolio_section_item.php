<?php

$manifesto_current_item_count = get_query_var('manifesto_query_var_item_count');
$manifesto_portfolio_items = manifesto_portfolio_thumbs_list();

// validate the current portfolio index
if( array_key_exists( $manifesto_current_item_count-1, $manifesto_portfolio_items ) ) {
	
	$manifesto_portfolio_item = $manifesto_portfolio_items[$manifesto_current_item_count-1];
	
	$manifesto_hero_properties = new Manifesto_Hero_Properties();
	$manifesto_hero_properties->post_id = $manifesto_portfolio_item->post_id;
	$manifesto_hero_properties->getProperties( 'manifesto_portfolio' );
	
	$manifesto_hero_image 		= $manifesto_hero_properties->image;
	$manifesto_background_type 	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-bknd-color' );
	$manifesto_caption_title	= $manifesto_hero_properties->caption_title;
	$manifesto_project_year		= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-project-year' );
	
	$manifesto_item_classes = "";
	$manifesto_item_categories = '';
	$manifesto_item_cats = get_the_terms( $manifesto_portfolio_item->post_id, 'portfolio_category' );
	if($manifesto_item_cats){

		foreach($manifesto_item_cats as $item_cat) {
			
			$manifesto_item_classes .= $item_cat->slug . ' ';
			$manifesto_item_categories .= $item_cat->name . ', ';
		}

		$manifesto_item_categories = rtrim( $manifesto_item_categories, ', ');

	}
		
	$item_url = get_the_permalink( $manifesto_portfolio_item->post_id );
	
	$manifesto_change_header = "";
	$manifesto_current_page_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-bknd-color' );
	if( $manifesto_background_type  == 'dark-content' ){
							
		$manifesto_change_header = "change-header";
	}
	
?>
						<div class="clapat-item <?php echo esc_attr( $manifesto_item_classes ); ?>">
							<div class="slide-inner trigger-item <?php echo sanitize_html_class( $manifesto_change_header ); ?>" data-centerLine="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_open_project_caption') ); ?>">
								<div class="img-mask">
									<a class="slide-link" data-type="page-transition" href="<?php echo esc_url( $item_url ); ?>"></a>
										<div class="section-image trigger-item-link">
											<img src="<?php echo esc_url( $manifesto_hero_image['url'] ); ?>" class="item-image grid__item-img" alt="<?php echo esc_attr( manifesto_get_image_alt(  $manifesto_hero_image['id'] ) ); ?>">
											<?php if( $manifesto_hero_properties->video ){ ?>
											<div class="hero-video-wrapper">
												<video loop muted playsinline class="bgvid">
												<?php if( !empty( $manifesto_hero_properties->video_mp4 ) ){ ?>
													<source src="<?php echo esc_url( $manifesto_hero_properties->video_mp4 ); ?>" type="video/mp4">
												<?php } ?>
												<?php if( !empty( $manifesto_hero_properties->video_webm ) ){ ?>
													<source src="<?php echo esc_url( $manifesto_hero_properties->video_webm ); ?>" type="video/webm">
												<?php } ?>
												</video>
											</div>
											<?php } ?>
										</div>
										<img src="<?php echo esc_url( $manifesto_hero_image['url'] ); ?>" class="grid__item-img grid__item-img--large" alt="<?php echo esc_attr( manifesto_get_image_alt(  $manifesto_hero_image['id'] ) ); ?>">
								</div>
								<div class="slide-caption trigger-item-link-secondary">
									<div class="slide-title"><?php echo wp_kses( $manifesto_caption_title, 'manifesto_allowed_html' ); ?></div>
									<div class="slide-date"><span><?php echo wp_kses( $manifesto_project_year, 'manifesto_allowed_html' ); ?></span></div>
									<div class="slide-cat"><span><?php echo wp_kses( $manifesto_item_categories, 'manifesto_allowed_html' ); ?></span></div>
									<div class="slide-icon"><i class="arrow-icon-down"></i></div>
								</div>
							</div>
						</div>
<?php

}
?>
