<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> data-primary-color="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_primary_color') ); ?>">
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>

	<main>
	<?php
		// display header section
		get_template_part('sections/preloader_section');
	?>
	
		<!--Cd-main-content -->
		<div class="cd-index cd-main-content">

		<?php
		$manifesto_bknd_color = "";
		if( is_singular( 'manifesto_portfolio' ) ){

			$manifesto_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-portfolio-bknd-color' );
			$manifesto_bknd_color_attribute = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-portfolio-bknd-color-code' );
		}
		else if( is_singular( 'post' ) ){

			$manifesto_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-blog-bknd-color' );
			$manifesto_bknd_color_attribute = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-blog-bknd-color-code' );
		}
		else if( is_404() ){

			$manifesto_bknd_color = manifesto_get_theme_options( 'clapat_manifesto_error_page_bknd_type' );
			$manifesto_bknd_color_attribute = "#ffffff";
			if( $manifesto_bknd_color == "light-content" ){

				$manifesto_bknd_color_attribute = "#0c0c0c";
			}

		}
		else if( is_page() ){

			$manifesto_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-bknd-color' );
			$manifesto_bknd_color_attribute = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-bknd-color-code' );
		}
		else if( function_exists( "is_woocommerce" ) ){
			
			if( is_shop() ){
						
				$page_id = wc_get_page_id('shop');
				$manifesto_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $page_id, 'manifesto-opt-page-bknd-color' );
				$manifesto_bknd_color_attribute = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $page_id, 'manifesto-opt-page-bknd-color-code' );
			}
			else if( is_product() ){
				
				$manifesto_bknd_color = manifesto_get_theme_options( 'clapat_manifesto_shop_product_page_bknd_type' );
				$manifesto_bknd_color_attribute =  manifesto_get_theme_options( 'clapat_manifesto_shop_product_page_bknd_color' );
			}
			
		}
		
		if( empty( $manifesto_bknd_color ) ){

			$manifesto_bknd_color = manifesto_get_theme_options( 'clapat_manifesto_default_page_bknd_type' );
			
			$manifesto_bknd_color_attribute = "#ffffff";
			if( $manifesto_bknd_color == "light-content" ){

				$manifesto_bknd_color_attribute = "#0c0c0c";
			}
		}

		?>

		<?php $manifesto_page_content_classes = ""; ?>

		<?php
		// Check if Elementor is installed and activated
		if ( did_action( 'elementor/loaded' ) ) {

			if( !empty( $manifesto_page_content_classes ) ){

				$manifesto_page_content_classes .= " ";
			}

			$manifesto_page_content_classes	.= "with-elementor";
		}
		?>
		
		<?php 
		$manifesto_is_woocommerce = false;
		if( function_exists( "is_woocommerce" ) ){
			
			if( is_woocommerce() ){
				
				$manifesto_is_woocommerce = true;
				
				if( is_shop() ){
					
					if( manifesto_get_theme_options( 'clapat_manifesto_shop_enable_custom_grid' ) ){
						
						$manifesto_page_content_classes .= " clapat-shop-grid";
					}
				}
				if( is_product() ){
					
					if( manifesto_get_theme_options( 'clapat_manifesto_sticky_shop_product_caption' ) ){
						
						$manifesto_page_content_classes .= " clapat-shop-product-summary-sticky";
					}
				}
			}
		}
		?>
		
		<?php if( ( is_page_template( 'blog-page.php' ) || is_home() || is_archive() || is_search() ) && !$manifesto_is_woocommerce ){ ?>
			<!-- Page Content -->
			<div id="page-content" class="blog-template-content <?php echo sanitize_html_class( $manifesto_bknd_color ); if( !manifesto_get_theme_options( 'clapat_manifesto_enable_magic_cursor' ) ){ echo " magic-cursor-disabled"; } ?> <?php echo esc_attr( $manifesto_page_content_classes ); ?>" data-bgcolor="<?php echo esc_attr( $manifesto_bknd_color_attribute ); ?>" >
		<?php } else if( is_singular( 'post' ) ){ ?>
			<!-- Page Content -->
			<div id="page-content" class="post-template-content <?php echo sanitize_html_class( $manifesto_bknd_color ); if( !manifesto_get_theme_options( 'clapat_manifesto_enable_magic_cursor' ) ){ echo " magic-cursor-disabled"; } ?> <?php echo esc_attr( $manifesto_page_content_classes ); ?>" data-bgcolor="<?php echo esc_attr( $manifesto_bknd_color_attribute ); ?>" >
		<?php } else { ?>
			<!-- Page Content -->
			<div id="page-content" class="<?php echo sanitize_html_class( $manifesto_bknd_color ); if( !manifesto_get_theme_options( 'clapat_manifesto_enable_magic_cursor' ) ){ echo " magic-cursor-disabled"; } ?> <?php echo esc_attr( $manifesto_page_content_classes ); ?>" data-bgcolor="<?php echo esc_attr( $manifesto_bknd_color_attribute ); ?>" >
		<?php } ?>

		<?php
			// display header section
			get_template_part('sections/header_section');
		?>