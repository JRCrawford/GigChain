<?php

// more widgets in the (near) future...

// Register widgetized locations
if(  !function_exists('manifesto_widgets_init') ){

    function manifesto_widgets_init(){

		$args = 			array( 'name'		=> esc_html__( 'Blog Sidebar', 'manifesto' ),
								'id'           	=> 'manifesto-blog-sidebar',
								'description'  	=> '',
								'class'        	=> '',
								'before_widget'	=> '<div id="%1$s" class="widget clapat-sidebar-widget %2$s">',
								'after_widget'  => '</div>',
								'before_title'  => '<h5 class="widgettitle clapat-widgettitle">',
								'after_title'   => '</h5>' );
		
		register_sidebar( $args );
		
		if( function_exists( "is_woocommerce" ) ){
			
			$args = 			array( 'name'		=> esc_html__( 'Shop Sidebar', 'manifesto' ),
									'id'           	=> 'manifesto-shop-sidebar',
									'description'  	=> '',
									'class'        	=> '',
									'before_widget'	=> '<div id="%1$s" class="widget clapat-shop-sidebar-widget %2$s">',
									'after_widget'  => '</div>',
									'before_title'  => '<h5 class="widgettitle clapat-shop-widgettitle">',
									'after_title'   => '</h5>' );
			
			register_sidebar( $args );
		}
		        
    }
}

add_action( 'widgets_init', 'manifesto_widgets_init' );

?>