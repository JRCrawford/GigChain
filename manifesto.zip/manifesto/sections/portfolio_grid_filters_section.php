							<!-- Filters -->
							<div class="filters-options-wrapper">
								<a id="all" href="#" data-filter="" class="filter-option is_active">
									<span class="link" data-hover="<?php echo esc_attr( manifesto_get_theme_options( 'clapat_manifesto_portfolio_filter_all_caption' ) ); ?>">
										<?php echo wp_kses( manifesto_get_theme_options( 'clapat_manifesto_portfolio_filter_all_caption' ), 'manifesto_allowed_html' ); ?>
									</span>
								</a>
								<?php
										
									// check if the category filter is specified in page options
									$manifesto_portfolio_category_filter	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-filter-category' );

									$manifesto_portfolio_category = null;
									if( !empty( $manifesto_portfolio_category_filter ) ){
					
										$manifesto_portfolio_category = array();
										$manifesto_category_slugs = explode( ",", $manifesto_portfolio_category_filter );
										foreach( $manifesto_category_slugs as $manifesto_category_slug ){
														
											$manifesto_category_object = get_term_by( 'slug', $manifesto_category_slug, 'portfolio_category' );
											if( $manifesto_category_object ){
															
												array_push( $manifesto_portfolio_category, $manifesto_category_object );
											}
										}
									}
									else {

										$manifesto_portfolio_category = get_terms('portfolio_category', array( 'hide_empty' => 0 ));
									}

									if( $manifesto_portfolio_category ){

										foreach( $manifesto_portfolio_category as $portfolio_cat ){

								?>
								<a class="filter-option" href="#" data-filter="<?php echo sanitize_title( $portfolio_cat->slug ); ?>">
									<span class="link" data-hover="<?php echo esc_attr( $portfolio_cat->name ); ?>">
										<?php echo wp_kses( $portfolio_cat->name, 'manifesto_allowed_html' ); ?>
									</span>
								</a>
								<?php
								
										}
									}

								?>	
							</div>
							<!-- Filters -->