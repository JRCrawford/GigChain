<?php
/**
 * Created by Clapat.
 * Date: 14/07/23
 * Time: 1:34 PM
 */
 
$manifesto_enable_list_view	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-grid-enable-list-view' );
$manifesto_enable_shuffle_grid	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-grid-enable-shuffle-grid' );

$manifesto_portfolio_lists_view_caption	= manifesto_get_theme_options( 'clapat_manifesto_showcase_grid_view_list_caption' );
$manifesto_portfolio_grid_view_caption	= manifesto_get_theme_options( 'clapat_manifesto_showcase_grid_view_grid_caption' );
$manifesto_portfolio_shuffle_grid_caption = manifesto_get_theme_options( 'clapat_manifesto_showcase_grid_shuffle_grid_caption' );
 
$manifesto_hero_properties = new Manifesto_Hero_Properties();
$manifesto_hero_properties->getProperties( get_post_type() );

$manifesto_hero_styles = $manifesto_hero_properties->width;

if( !empty( $manifesto_hero_properties->alignment ) ){
		
	$manifesto_hero_styles .= " " . $manifesto_hero_properties->alignment;
}
if( !empty( $manifesto_hero_properties->scroll_position ) ){
		
	$manifesto_hero_styles .= " " . $manifesto_hero_properties->scroll_position;
}
if( !empty( $manifesto_hero_properties->subtitle_indent ) ){
		
	$manifesto_hero_styles .= " " . $manifesto_hero_properties->subtitle_indent;
}
if( !empty( $manifesto_hero_properties->bottom_padding ) ){
		
	$manifesto_hero_styles .= " " . $manifesto_hero_properties->bottom_padding;
}

$manifesto_hero_title = $manifesto_hero_properties->caption_title;
if( !$manifesto_hero_properties->enabled ){
	
	$manifesto_hero_title = get_the_title();
} 
?>
					
		<?php if( $manifesto_hero_properties->image && !empty( $manifesto_hero_properties->image['url'] ) && $manifesto_hero_properties->enabled ){ ?>
		<!-- Hero Section -->
		<div id="hero" class="has-image">
			<div id="hero-styles">
				<div id="hero-caption" class="<?php echo esc_attr( $manifesto_hero_styles ); ?>">
					<div class="inner">
						<h1 class="hero-title caption-timeline"><?php echo wp_kses( $manifesto_hero_title, 'manifesto_allowed_html' ); ?></h1>
						<?php if( !empty( $manifesto_hero_properties->caption_subtitle ) ){ ?>
						<div class="hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_subtitle, 'manifesto_allowed_html' ); ?></div>
						<?php } ?>
					</div>
				</div>
				<div id="hero-footer" class="has-border<?php if( !$manifesto_enable_list_view && !$manifesto_enable_shuffle_grid ) { echo ' no-grid-option'; } ?>">
					<?php if( $manifesto_enable_list_view || $manifesto_enable_shuffle_grid ) { ?>
					<div class="hero-footer-left">
						<div class="grid-options-wrapper">
							<?php if( $manifesto_enable_list_view ) { ?>
							<a class="grid-option list-view" href="#">
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_lists_view_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_lists_view_caption, 'manifesto_allowed_html' ); ?></span>
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_grid_view_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_grid_view_caption, 'manifesto_allowed_html' ); ?></span>
							</a>
							<?php } ?>
							<?php if( $manifesto_enable_shuffle_grid ) { ?>
							<a class="grid-option shuffle-grid" href="#">
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_shuffle_grid_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_shuffle_grid_caption, 'manifesto_allowed_html' ); ?></span>
							</a>
							<?php } ?>
						</div>
					</div>
					<?php } ?>
					<div class="hero-footer-right">
                
						<?php get_template_part('sections/portfolio_grid_filters_section');  ?>
                                    
					</div>
				</div>
			</div>
		</div>
		<div id="hero-image-wrapper">
			<div id="hero-background-layer" class="parallax-scroll-image">
				<div id="hero-bg-image" style="background-image:url(<?php echo esc_url( $manifesto_hero_properties->image['url'] ); ?>)">
				<?php if( $manifesto_hero_properties->video ){ ?>
					<div class="hero-video-wrapper">
						<video loop muted playsinline class="bgvid">
						<?php if( !empty( $manifesto_hero_properties->video_mp4 ) ){ ?>
							<source src="<?php echo esc_url( $manifesto_hero_properties->video_mp4 ); ?>" type="video/mp4">
						<?php } ?>
						<?php if( !empty( $manifesto_hero_properties->video_webm ) ){ ?>
							<source src="<?php echo esc_url( $manifesto_hero_properties->video_webm ); ?>" type="video/webm">
						<?php } ?>
						</video>
					</div>
				<?php } ?>
				</div>
			</div>
		</div>
		<!--/Hero Section -->
		<?php } else { ?>
		<!-- Hero Section -->
		<div id="hero" <?php if( !$manifesto_hero_properties->enabled && !manifesto_get_theme_options( 'clapat_manifesto_enable_page_title_as_hero' ) ){ echo 'class="hero-hidden"'; } ?>>
			<div id="hero-styles">
				<div id="hero-caption" class="<?php echo esc_attr( $manifesto_hero_styles ); ?>">
					<div class="inner">
						<h1 class="hero-title caption-timeline"><?php echo wp_kses( $manifesto_hero_title, 'manifesto_allowed_html' ); ?></h1>
						<?php if( !empty( $manifesto_hero_properties->caption_subtitle ) ){ ?>
						<div class="hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_subtitle, 'manifesto_allowed_html' ); ?></div>
						<?php } ?>
					</div>
				</div>
				<div id="hero-footer" class="has-border<?php if( !$manifesto_enable_list_view && !$manifesto_enable_shuffle_grid ) { echo ' no-grid-option'; } ?>">
					<?php if( $manifesto_enable_list_view || $manifesto_enable_shuffle_grid ) { ?>
					<div class="hero-footer-left">
						<div class="grid-options-wrapper">
							<?php if( $manifesto_enable_list_view ) { ?>
							<a class="grid-option list-view" href="#">
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_lists_view_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_lists_view_caption, 'manifesto_allowed_html' ); ?></span>
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_grid_view_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_grid_view_caption, 'manifesto_allowed_html' ); ?></span>
							</a>
							<?php } ?>
							<?php if( $manifesto_enable_shuffle_grid ) { ?>
							<a class="grid-option shuffle-grid" href="#">
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_portfolio_shuffle_grid_caption ); ?>"><?php echo wp_kses( $manifesto_portfolio_shuffle_grid_caption, 'manifesto_allowed_html' ); ?></span>
							</a>
							<?php } ?>
						</div>
					</div>
					<?php } ?>
					<div class="hero-footer-right">
                
						<?php get_template_part('sections/portfolio_grid_filters_section');  ?>
                                    
					</div>
				</div>
			</div>
		</div>
		<!--/Hero Section -->
		<?php } ?>
