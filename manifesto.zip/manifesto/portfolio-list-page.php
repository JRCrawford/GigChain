<?php
/*
Template name: Portfolio List
*/

get_header();

if ( have_posts() ){

	the_post();
	
	$manifesto_current_page_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-bknd-color' );

	$manifesto_portfolio_thumb_to_fullscreen = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen' );
	if( !manifesto_get_theme_options('clapat_manifesto_enable_ajax') ){
		
		$manifesto_portfolio_thumb_to_fullscreen = 'no-fitthumbs';
	}
	$manifesto_portfolio_thumb_to_fullscreen_webgl_type = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen-webgl-type' );

	$manifesto_showcase_tax_query = null;
	$manifesto_showcase_category_filter	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-filter-category' );

	if( !empty( $manifesto_showcase_category_filter ) ){

		$manifesto_array_terms = explode( ",", $manifesto_showcase_category_filter );
		$manifesto_showcase_tax_query = array(
											array(
												'taxonomy' 	=> 'portfolio_category',
												'field'		=> 'slug',
												'terms'		=> $manifesto_array_terms,
												),
										);
	}
?>

		<!-- Main -->
		<div id="main">

			<!-- Main Content -->
			<div id="main-content">

				<!-- Showcase Carousel Holder -->
				<div id="itemsWrapperLinks">
					<div id="itemsWrapper" class="<?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen ); ?> <?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen_webgl_type ); ?>">
						
						<!-- ClaPat Slider -->
						<div class="clapat-slider-wrapper showcase-lists<?php if( !manifesto_get_theme_options('clapat_manifesto_enable_ajax') ) { echo ' thumb-no-ajax'; } ?>">
							<div class="clapat-slider">

								<!-- ClaPat Main Slider -->
								<div class="clapat-slider-viewport">
								<?php

									$manifesto_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
									$manifesto_args = array(
														'post_type' => 'manifesto_portfolio',
														'paged' => $manifesto_paged,
														'tax_query' => $manifesto_showcase_tax_query,
														'posts_per_page' => 1000,
													);

									$manifesto_portfolio = new WP_Query( $manifesto_args );

									$manifesto_slides_count = 0;
									$manifesto_portfolio_items = array();
									while( $manifesto_portfolio->have_posts() ){

										$manifesto_portfolio->the_post();

										$manifesto_bknd_color			= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-portfolio-bknd-color' );
																			
										$manifesto_hero_properties = new Manifesto_Hero_Properties();
										$manifesto_hero_properties->getProperties( get_post_type( get_the_ID() ) );									

								?>

									<div class="clapat-slide">
										<div class="slide-inner"></div>
									</div>

								<?php

										$manifesto_portfolio_items[] = $manifesto_hero_properties;

										$manifesto_slides_count++;

									}

									wp_reset_postdata();
									
									manifesto_portfolio_thumbs_list( $manifesto_portfolio_items );

								?>
								</div>
								<!-- /ClaPat Main Slider -->
								
								<!-- ClaPat Sync Slider -->
								<div class="clapat-sync-slider">
									<div class="clapat-sync-slider-wrapper">
										<div class="clapat-sync-slider-viewport">
											
											<?php
											foreach( $manifesto_portfolio_items as $manifesto_hero_properties ){
												
												$manifesto_bknd_color			= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_hero_properties->post_id, 'manifesto-opt-portfolio-bknd-color' );
												
												$manifesto_change_header		= "";
												if( $manifesto_bknd_color == 'dark-content' ){
												
													$manifesto_change_header = "change-header";
												}
												
												$item_url = get_the_permalink( $manifesto_hero_properties->post_id );
											?>
											<div class="clapat-sync-slide">                                                	
												<div class="slide-inner trigger-item <?php echo sanitize_html_class( $manifesto_change_header ); ?>" data-centerLine="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_open_project_caption') ); ?>">
													<div class="hover-reveal">
														<div class="hover-reveal__inner">
															<div class="hover-reveal__img">
																<img src="<?php echo esc_url( $manifesto_hero_properties->image['url'] ); ?>" class="item-image grid__item-img" alt="<?php echo manifesto_get_image_alt( $manifesto_hero_properties->image['id'] ); ?>">
																<?php if( $manifesto_hero_properties->video ){

																	$manifesto_video_webm_url 	= $manifesto_hero_properties->video_webm;
																	$manifesto_video_mp4_url 	= $manifesto_hero_properties->video_mp4;
																?>
																<div class="hero-video-wrapper">
																	<video loop muted playsinline class="bgvid">
																	<?php if( !empty( $manifesto_video_mp4_url ) ) { ?>
																		<source src="<?php echo esc_url( $manifesto_video_mp4_url ); ?>" type="video/mp4">
																	<?php } ?>
																	<?php if( !empty( $manifesto_video_webm_url ) ) { ?>
																		<source src="<?php echo esc_url( $manifesto_video_webm_url ); ?>" type="video/webm">
																	<?php } ?>
																	</video>
																</div>
																<?php } ?>
																<img class="grid__item-img grid__item-img--large" src="<?php echo esc_url( $manifesto_hero_properties->image['url'] ); ?>" alt="<?php echo manifesto_get_image_alt( $manifesto_hero_properties->image['id'] ); ?>" />
															</div>
														</div>
													</div>
                                                            
													<a data-type="page-transition" href="<?php echo esc_url( $item_url ); ?>"></a>
													<div class="slide-title trigger-item-link">
														<span><?php echo wp_kses( $manifesto_hero_properties->caption_title, 'manifesto_allowed_html' ); ?></span>
													</div>
												</div>
											</div>
											<?php
											}
											?>

										</div>
									</div>
								</div>

							</div>
						
							<div class="carousel-nav-wrapper">
								<div class="carousel-prev cp-button-prev">
									<div class="icon-wrap parallax-wrap">
										<div class="button-icon parallax-element">
											<i class="fa-solid fa-minus"></i>
										</div>
									</div>
								</div>
								<div class="carousel-next cp-button-next">
									<div class="icon-wrap parallax-wrap">
										<div class="button-icon parallax-element">
											<i class="fa-solid fa-plus"></i>
										</div>
									</div>
								</div>
							</div>
						
						</div>
						<!-- /ClaPat Slider -->
						
					</div>
				</div>
				<!-- /Showcase Carousel Holder -->

			</div>
			<!--/Main Content -->

		</div>
		<!--/Main -->

<?php

}

get_footer();

?>