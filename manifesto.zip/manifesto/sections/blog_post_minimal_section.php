<?php
$manifesto_post_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');

$manifesto_post_title = get_the_title();
if( empty( $manifesto_post_title ) ){
	
	$manifesto_post_title = esc_html__("Post has no title", "manifesto");
}

?>
				
				<!-- Article -->
				<article id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
					<div class="article-bg">
                        	
						<div class="article-content">
                            		
							<div class="entry-meta-wrap">    
								<div class="entry-meta entry-categories">
									<ul class="post-categories">
										<?php 
											$manifesto_categories = get_the_category();
											if ( ! empty( $manifesto_categories ) ) {

												foreach( $manifesto_categories as $manifesto_category ) {

													echo '<li class="link">';
													echo wp_kses( '<a class="ajax-link" data-type="page-transition" href="' . esc_url( get_category_link( $manifesto_category->term_id ) ) . '" rel="category tag"><span data-hover="' . esc_attr( $manifesto_category->name ) . '">' . esc_html( $manifesto_category->name ) . '</span></a>', 'manifesto_allowed_html' );
													echo '</li>';
												}
											}
										?>
									</ul>
								</div>
							</div>
							
                            <div class="entry-meta-wrap">
								<ul class="entry-meta entry-date">
									<li class="link"><a class="ajax-link" href="<?php the_permalink(); ?>"><span data-hover="<?php echo get_the_date(); ?>"><?php echo get_the_date(); ?></span></a></li>
								</ul>
							</div>
							
							
						</div>
                        
                        <div class="article-wrap">
							
                           <div class="article-show-image">
                            
								<?php if( $manifesto_post_image  ){ ?>
                                <div class="hover-reveal">
                                    <div class="hover-reveal__inner">
                                        <div class="hover-reveal__img">
                                            <a class="ajax-link" href="<?php echo esc_url( the_permalink() ); ?>" data-type="page-transition">
                                                <img src="<?php echo esc_url( $manifesto_post_image[0] ); ?>" alt="<?php esc_attr_e("Post Image", "manifesto"); ?>">                                      	 
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                                
                                <a class="post-title ajax-link hide-ball" href="<?php echo esc_url( the_permalink() ); ?>" data-type="page-transition"><?php echo wp_kses( $manifesto_post_title, 'manifesto_allowed_html' ); ?></a>
                            
                            </div>
                            
                            <div class="article-links">
                                <div class="button-box">
                                    <a class="ajax-link" data-type="page-transition" href="<?php the_permalink(); ?>">
                                        <div class="clapat-button-wrap parallax-wrap hide-ball">
                                            <div class="clapat-button parallax-element">
                                                <div class="button-border outline rounded parallax-element-second">
                                                    <span data-hover="<?php esc_attr_e('Read Article', 'manifesto'); ?>"><?php echo esc_html__('Read Article', 'manifesto'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="page-links">
                                <?php
                                    wp_link_pages();
                                ?>
                                </div>
    
                                <?php
                                if( manifesto_get_theme_options('clapat_manifesto_blog_excerpt_type') != 'blog-excerpt-none' ) {
                                ?>
                                <div class="blog-excerpt">
                                    <?php
                                    if( manifesto_get_theme_options('clapat_manifesto_blog_excerpt_type') == 'blog-excerpt-full' ) {
                                        
                                        the_content( esc_html__('Continue Reading...', 'manifesto') );
                                    }
                                    else {
                                        
                                        the_excerpt();
                                    }
                                ?>
                                </div>
                                <?php
                                }
                                ?>
                            </div>
                            
                            <div class="button-wrap right button-link">
                                <div class="icon-wrap parallax-wrap">
                                    <div class="button-icon parallax-element">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </div>
                                </div>
                                <a class="ajax-link" href="<?php echo esc_url( the_permalink() ); ?>" data-type="page-transition"><div class="button-text sticky right">
									<span data-hover="<?php echo esc_attr( manifesto_get_theme_options( 'clapat_manifesto_blog_read_more_caption' ) ); ?>"><?php echo wp_kses( manifesto_get_theme_options( 'clapat_manifesto_blog_read_more_caption' ), 'manifesto_allowed_html' ); ?></span></div>
                                </a> 
                            </div>
                            
						</div>
                        
					</div>
				</article>
				<!--/Article -->