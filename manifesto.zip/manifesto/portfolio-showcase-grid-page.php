<?php
/*
Template name: Portfolio Showcase Grid
*/
get_header();

if ( have_posts() ){

the_post();

$manifesto_portfolio_tax_query = null;
$manifesto_portfolio_category_filter = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-filter-category' );

$manifesto_portfolio_layout_type = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-grid-layout-type');

$manifesto_content_position	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-grid-content-position' );

$manifesto_portfolio_thumb_to_fullscreen	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen' );
if( !manifesto_get_theme_options('clapat_manifesto_enable_ajax') ){
	
	$manifesto_portfolio_thumb_to_fullscreen = 'no-fitthumbs';
}
$manifesto_portfolio_thumb_to_fullscreen_webgl_type = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen-webgl-type' );

$manifesto_array_terms = null;
if( !empty( $manifesto_portfolio_category_filter ) ){

	$manifesto_array_terms = explode( ",", $manifesto_portfolio_category_filter );
	$manifesto_portfolio_tax_query = array(
										array(
											'taxonomy' 	=> 'portfolio_category',
											'field'		=> 'slug',
											'terms'		=> $manifesto_array_terms,
											),
									);
}

// Select all portfolio items
$manifesto_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$manifesto_args = array(
					'post_type' => 'manifesto_portfolio',
					'paged' => $manifesto_paged,
					'tax_query' => $manifesto_portfolio_tax_query,
					'posts_per_page' => 1000,
					 );

$manifesto_portfolio = new WP_Query( $manifesto_args );

$manifesto_portfolio_items = array();

// collect the posts first
$manifesto_current_item_count = 1;
while( $manifesto_portfolio->have_posts() ){

	$manifesto_portfolio->the_post();

	$manifesto_hero_properties = new Manifesto_Hero_Properties();
	$manifesto_hero_properties->getProperties( get_post_type( get_the_ID() ) );
	$manifesto_hero_properties->item_no = $manifesto_current_item_count;
	$manifesto_portfolio_items[] = $manifesto_hero_properties;

	$manifesto_current_item_count++;

}

manifesto_portfolio_thumbs_list( $manifesto_portfolio_items );

wp_reset_postdata();

?>

			<!-- Main -->
			<div id="main">
			
				<?php
		
				// display hero section
				get_template_part('sections/hero_portfolio_grid_section'); 
		
				?>
			
				<!-- Main Content -->
				<div id="main-content">
				
					<!-- Main Page Content -->
					<div id="main-page-content">

						<!-- Showcase Slider Holder -->
						<div id="itemsWrapperLinks">
							<!-- Showcase Columns -->
							<div id="itemsWrapper" class="<?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen ); ?> <?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen_webgl_type ); ?>">
								
								<?php 
									if( $manifesto_content_position == "before" ){
										the_content();
									} 
								?>
								
								<!-- ClaPat Portfolio -->
								<div class="showcase-portfolio <?php echo sanitize_html_class( $manifesto_portfolio_layout_type ); ?>">

									<?php
											
										$manifesto_portfolio_items = manifesto_portfolio_thumbs_list();
											
										if( !empty( $manifesto_portfolio_items ) ){
											
											$manifesto_current_item_count = 1;
	
											foreach( $manifesto_portfolio_items as $manifesto_portfolio_item ){

												set_query_var('manifesto_query_var_item_count', $manifesto_current_item_count);

												get_template_part('sections/portfolio_section_item');
												
												$manifesto_current_item_count++;
											}

										}
										?>
										
								</div>
								<!-- /ClaPat Portfolio -->
								
								<?php 
									if( $manifesto_content_position == "after" ){
										the_content();
									} 
								?>
								
							</div>
							<!--/Showcase Columns -->
						</div>
						<!--/Showcase Slider Holder -->
					
					 </div>
					 <!-- /Main Page Content -->
					 <?php
		
					// display next page navigation section
					get_template_part('sections/page_navigation_section'); 
		
					?>
					
				</div>
				<!-- /Main Content -->
			</div>
			<!--/Main -->
<?php

}

get_footer();

?>
