					<?php
						$manifesto_gallery_enable_filters = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-gallery-enable-filters' );
						
						$manifesto_prev_page_id			= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-gallery-prev-page' );
						$manifesto_page_nav_enable		= !empty( $manifesto_prev_page_id );
						$manifesto_prev_page_url 		= get_permalink( $manifesto_prev_page_id );
						$manifesto_prev_page_caption	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-gallery-prev-page-caption' );
						
					?>
							
							<?php if( $manifesto_page_nav_enable ){ ?>
							<a class="ajax-link link-text" data-type="page-transition" href="<?php echo esc_url( $manifesto_prev_page_url ); ?>">
								<span class="link" data-hover="<?php echo esc_attr( $manifesto_prev_page_caption ); ?>"><?php echo wp_kses( $manifesto_prev_page_caption, 'manifesto_allowed_html' ); ?></span>
							</a>
							<?php } ?>

							<?php if( $manifesto_gallery_enable_filters ) { ?>
							<!-- Filters -->
							<div id="filters-wrapper" class="link">
								<div class="active-filter-bg"></div>
								<ul id="filters">
									<li class="filters-timeline link active"><a id="all" href="#" data-filter="*" class="active hide-ball"><?php echo wp_kses( manifesto_get_theme_options( 'clapat_manifesto_portfolio_filter_all_caption' ), 'manifesto_allowed_html' ); ?></a></li>
									<?php
										
									// check if the category filter is specified in page options
									$manifesto_portfolio_category_filter	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-filter-category' );

									$manifesto_portfolio_category = null;
									if( !empty( $manifesto_portfolio_category_filter ) ){
					
										$manifesto_portfolio_category = array();
										$manifesto_category_slugs = explode( ",", $manifesto_portfolio_category_filter );
										foreach( $manifesto_category_slugs as $manifesto_category_slug ){
														
											$manifesto_category_object = get_term_by( 'slug', $manifesto_category_slug, 'portfolio_category' );
											if( $manifesto_category_object ){
															
												array_push( $manifesto_portfolio_category, $manifesto_category_object );
											}
										}
									}
									else {

										$manifesto_portfolio_category = get_terms('portfolio_category', array( 'hide_empty' => 0 ));
									}

									if( $manifesto_portfolio_category ){

										foreach( $manifesto_portfolio_category as $portfolio_cat ){

										?>
										<li class="filters-timeline link"><a href="#" data-filter=".<?php echo sanitize_title( $portfolio_cat->slug ); ?>" class="hide-ball"><?php echo wp_kses( $portfolio_cat->name, 'manifesto_allowed_html' ); ?></a></li>
										<?php

										}
									}

									?>
								</ul>
								
								<div class="toggle-filters"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_portfolio_show_filters_caption'), 'manifesto_allowed_html' ); ?></div>
							</div>
							<!-- Filters -->
							<?php } ?>
							
							<div class="progress-info fadeout-element">
								<div class="progress-info-fill"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_showcase_scroll_drag_caption'), 'manifesto_allowed_html') ?></div>
								<div class="progress-info-fill-2"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_showcase_scroll_drag_caption'), 'manifesto_allowed_html') ?></div>
							</div>