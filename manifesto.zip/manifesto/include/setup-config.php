<?php
/**
 * Created by Clapat.
 * Date: 22/07/23
 * Time: 6:21 AM
 */

// register navigation menus
if ( ! function_exists( 'manifesto_register_nav_menus' ) ){
	
	function manifesto_register_nav_menus() {
		
	  register_nav_menus(
		array(
		  'primary-menu' => esc_html__( 'Primary Menu', 'manifesto')
		)
	  );
	}
}
add_action( 'init', 'manifesto_register_nav_menus' );
 
// theme setup
if ( ! function_exists( 'manifesto_theme_setup' ) ){

	function manifesto_theme_setup() {

		// Set content width
		if ( ! isset( $content_width ) ) $content_width = 1180;

		// add support for multiple languages
		load_theme_textdomain( 'manifesto', get_template_directory() . '/languages' );
			
	}

} // manifesto_theme_setup

/**
 * Tell WordPress to run manifesto_theme_setup() when the 'after_setup_theme' hook is run.
 */
add_action( 'after_setup_theme', 'manifesto_theme_setup' );