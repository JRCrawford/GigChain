<?php
/*
Template name: Portfolio Showcase Gallery
*/
get_header();

if ( have_posts() ){

the_post();

$manifesto_portfolio_tax_query = null;
$manifesto_portfolio_category_filter = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-filter-category' );

$manifesto_gallery_enable_preview = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-gallery-enable-preview' );
$manifesto_gallery_enable_tilt = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-gallery-enable-tilt' );

$manifesto_portfolio_thumb_to_fullscreen	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen' );
if( !manifesto_get_theme_options('clapat_manifesto_enable_ajax') ){
	
	$manifesto_portfolio_thumb_to_fullscreen = 'no-fitthumbs';
}
$manifesto_portfolio_thumb_to_fullscreen_webgl_type = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-thumb-to-fullscreen-webgl-type' );

$manifesto_array_terms = null;
if( !empty( $manifesto_portfolio_category_filter ) ){

	$manifesto_array_terms = explode( ",", $manifesto_portfolio_category_filter );
	$manifesto_portfolio_tax_query = array(
										array(
											'taxonomy' 	=> 'portfolio_category',
											'field'		=> 'slug',
											'terms'		=> $manifesto_array_terms,
											),
									);
}

// Select all portfolio items
$manifesto_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$manifesto_args = array(
					'post_type' => 'manifesto_portfolio',
					'paged' => $manifesto_paged,
					'tax_query' => $manifesto_portfolio_tax_query,
					'posts_per_page' => 1000,
					 );

$manifesto_portfolio = new WP_Query( $manifesto_args );

$manifesto_portfolio_items = array();

// collect the posts first
$manifesto_current_item_count = 1;
while( $manifesto_portfolio->have_posts() ){

	$manifesto_portfolio->the_post();

	$manifesto_hero_properties = new Manifesto_Hero_Properties();
	$manifesto_hero_properties->getProperties( get_post_type( get_the_ID() ) );
	$manifesto_hero_properties->item_no = $manifesto_current_item_count;
	$manifesto_portfolio_items[] = $manifesto_hero_properties;

	$manifesto_current_item_count++;

}

manifesto_portfolio_thumbs_list( $manifesto_portfolio_items );

wp_reset_postdata();

?>

			<!-- Main -->
			<div id="main">
			
				<!-- Main Content -->
				<div id="main-content">
				
					<!-- Showcase Slider Holder -->
					<div id="itemsWrapperLinks">
						<!-- Showcase Columns -->
						<div id="itemsWrapper" class="<?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen ); ?> <?php echo sanitize_html_class( $manifesto_portfolio_thumb_to_fullscreen_webgl_type ); ?>">
                            
                           	<!-- ClaPat Slider -->
							<div class="clapat-slider-wrapper showcase-gallery<?php if( $manifesto_gallery_enable_preview ) { echo ' preview-mode-enabled'; } ?><?php if( $manifesto_gallery_enable_tilt ){ echo ' tilt-gallery'; } ?>">
								<div class="clapat-slider">
                                      	
									<!-- ClaPat Main Slider -->
									<div class="clapat-slider-viewport">

									<?php

									$manifesto_portfolio_items = manifesto_portfolio_thumbs_list();

									if( !empty( $manifesto_portfolio_items ) ){
											
										$manifesto_current_item_count = 1;

										foreach( $manifesto_portfolio_items as $manifesto_portfolio_item ){

											$manifesto_thumb_offset = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-thumb-gallery-offset' );
											$manifesto_thumb_scale = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-thumb-gallery-scale' );
											$manifesto_gallery_enable_parallax = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-gallery-enable-parallax' );
											$manifesto_background_type = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, $manifesto_portfolio_item->post_id, 'manifesto-opt-portfolio-bknd-color' );
											
											$manifesto_item_classes = "";
											$manifesto_item_categories = '';
											$manifesto_item_cats = get_the_terms( $manifesto_portfolio_item->post_id, 'portfolio_category' );
											if($manifesto_item_cats){

												foreach($manifesto_item_cats as $item_cat) {
													
													$manifesto_item_classes .= $item_cat->slug . ' ';
													$manifesto_item_categories .= $item_cat->name . ', ';
												}

												$manifesto_item_categories = rtrim( $manifesto_item_categories, ', ');

											}
												
											$item_url = get_the_permalink( $manifesto_portfolio_item->post_id );
											
											$manifesto_change_header = "";
											$manifesto_current_page_bknd_color = manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-bknd-color' );
											if( $manifesto_background_type  == 'dark-content' ){
																	
												$manifesto_change_header = "change-header";
											}
									?>
										<div class="clapat-slide <?php echo sanitize_html_class( $manifesto_thumb_offset ); ?>">
											<div class="slide-events <?php echo sanitize_html_class( $manifesto_thumb_scale ); ?><?php if( $manifesto_gallery_enable_parallax ) echo ' speed-50'; ?>">
												<div class="slide-inner <?php echo esc_attr( $manifesto_item_classes ); ?>" data-centerLine="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_view_project_caption') ); ?>">
													<div class="slide-moving">
														<div class="trigger-item <?php echo sanitize_html_class( $manifesto_change_header ); ?>" data-centerLine="<?php echo esc_attr( manifesto_get_theme_options('clapat_manifesto_open_project_caption') ); ?>">
															<div class="img-mask">
																<a class="slide-link" data-type="page-transition" href="<?php echo esc_url( $item_url ); ?>">
																	<div class="parallax-wrap">
																		<div class="parallax-element">
																			<i class="fa-solid fa-arrow-up-right-from-square"></i>
																		</div>
																	</div>
																</a>
																<div class="section-image trigger-item-link">
																	<img src="<?php echo esc_url( $manifesto_portfolio_item->image['url'] ); ?>" class="item-image grid__item-img" alt="<?php echo esc_attr( manifesto_get_image_alt(  $manifesto_portfolio_item->image['id'] ) ); ?>">
																	<?php if( $manifesto_portfolio_item->video ){ ?>
																		<div class="hero-video-wrapper">
																			<video loop muted playsinline class="bgvid">
																			<?php if( !empty( $manifesto_portfolio_item->video_mp4 ) ){ ?>
																				<source src="<?php echo esc_url( $manifesto_portfolio_item->video_mp4 ); ?>" type="video/mp4">
																			<?php } ?>
																			<?php if( !empty( $manifesto_portfolio_item->video_webm ) ){ ?>
																				<source src="<?php echo esc_url( $manifesto_portfolio_item->video_webm ); ?>" type="video/webm">
																			<?php } ?>
																			</video>
																		</div>
																		<?php } ?>
																</div> 
																<img src="<?php echo esc_url( $manifesto_portfolio_item->image['url'] ); ?>" class="grid__item-img grid__item-img--large" alt="<?php echo esc_attr( manifesto_get_image_alt(  $manifesto_portfolio_item->image['id'] ) ); ?>">
															</div>
														</div>
														<div class="slide-caption">
															<div class="slide-title"><?php echo wp_kses( $manifesto_portfolio_item->caption_title, 'manifesto_allowed_html' ); ?></div>
															<div class="slide-cat"><span><?php echo wp_kses( $manifesto_item_categories, 'manifesto_allowed_html' ); ?></span></div>
														</div>
													</div>
												</div>
											</div>
										</div>
											
									<?php

											$manifesto_current_item_count++;
										}

									}
									
									?>
										
									</div>
									<!-- /ClaPat Main Slider -->
									<?php
									$manifesto_hero_properties = new Manifesto_Hero_Properties();
									$manifesto_hero_properties->getProperties( get_post_type( get_the_ID() ) );
									?>
									<div class="slider-fixed-content">
										<div id="slide-inner-temporary" class="fadeout-element">
											<div id="slide-inner-caption" class="content-full-width text-align-center block-title">
												<div class="inner">
													<h1 class="slide-hero-title caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_title, 'manifesto_allowed_html' ); ?></h1>
													<div class="slide-hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_subtitle, 'manifesto_allowed_html' ); ?></div>
												</div>
											</div> 
										</div>
									</div>

								</div>
								
								<div class="gallery-zoom-wrapper"></div>
								<div class="gallery-thumbs-wrapper"></div>
								<div class="gallery-close-thumbs"></div>
                                    
								<div class="carousel-nav-wrapper">
									<div class="carousel-prev cp-button-prev">
										<div class="icon-wrap parallax-wrap">
											<div class="button-icon parallax-element">
												<i class="fa-solid fa-minus"></i>
											</div>
										</div>
									</div>
									<div class="carousel-next cp-button-next">
										<div class="icon-wrap parallax-wrap">
											<div class="button-icon parallax-element">
												<i class="fa-solid fa-plus"></i>
											</div>
										</div>
									</div>
								</div>
									
							</div>
							<!-- /ClaPat Slider -->

						</div>
						<!--/Showcase Columns -->
					</div>
					<!--/Showcase Slider Holder -->

				</div>
				<!-- /Main Content -->
				
			</div>
			<!--/Main -->
<?php

}

get_footer();

?>