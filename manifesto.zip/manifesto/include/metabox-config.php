<?php

// You may replace $redux_opt_name with a string if you wish. If you do so, change loader.php
// as well as all the instances below.
$redux_opt_name = 'clapat_' . MANIFESTO_THEME_ID . '_theme_options';


if ( !function_exists( "manifesto_add_metaboxes" ) ){

    function manifesto_add_metaboxes( $metaboxes ) {

    $metaboxes = array();


    ////////////// Page Options //////////////
    $page_options = array();
    $page_options[] = array(
        'title'         => esc_html__('General', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-wrench',
        'desc'          => esc_html__('Options concerning all page templates.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-page-bknd-color-code',
                'type'      => 'color-picker',
                'title'     => esc_html__('Background color', 'manifesto'),
				'desc'      => esc_html__('Background color for this page.', 'manifesto'),
                'default'   => '#0c0c0c',
            ),
			
			array(
                'id'        => 'manifesto-opt-page-bknd-color',
                'type'      => 'select',
                'title'     => esc_html__('Background Type', 'manifesto'),
				'desc'      => esc_html__('Background type for this page.', 'manifesto'),
                'options'   => array(
                    'dark-content' 	=> esc_html__('Light', 'manifesto'),
                    'light-content' => esc_html__('Dark', 'manifesto')

                ),
				'default'   => 'light-content',
            )
			
        ),
    );

	$page_options[] = array(
        'title'         => esc_html__('Hero Section', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-website',
        'desc'          => esc_html__('Options concerning Hero top section in pages.', 'manifesto'),
        'fields'        => array(

			/**************************HERO SECTION OPTIONS**************************/
			array(
                'id'        => 'manifesto-opt-page-enable-hero',
                'type'      => 'switch',
                'title'     => esc_html__('Display Hero Section', 'manifesto'),
                'desc'      => esc_html__('Enable "hero" section displayed immediately below page header. Showcase and Carousel pages do not have a hero section.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => false
            ),

			array(
				'id'        => 'manifesto-opt-page-hero-img',
                'type'      => 'media',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
                'url'       => true,
                'title'     => esc_html__('Hero Image', 'manifesto'),
                'desc'      => esc_html__('Upload hero background image. The hero image is the fullscreen image in hero section. Hero section is the intro section displayed at the top of the page.', 'manifesto'),
                'default'   => array(),
            ),
			
			array(
				'id'        => 'manifesto-opt-page-video',
				'type'      => 'switch',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
				'title'     => esc_html__('Video Hero', 'manifesto'),
				'desc'   	=> esc_html__('Video displayed as hero section in project page. If you check this option set the Hero Image as the first frame image of the video to avoid flickering!', 'manifesto'),
				'on'       	=> esc_html__('Yes', 'manifesto'),
				'off'      	=> esc_html__('No', 'manifesto'),
				'default'   => false
			),

			array(
				'id'        => 'manifesto-opt-page-video-webm',
				'type'      => 'text',
				'title'     => esc_html__('Webm Video URL', 'manifesto'),
				'desc'   	=> esc_html__('URL of the hero section background webm video. Webm format is previewed in Chrome and Firefox.', 'manifesto'),
				'required'	=> array('manifesto-opt-page-video', '=', true),
			),

			array(
				'id'        => 'manifesto-opt-page-video-mp4',
				'type'      => 'text',
				'title'     => esc_html__('MP4 Video URL', 'manifesto'),
				'desc'   	=> esc_html__('URL of the hero section background MP4 video. MP4 format is previewed in IE, Safari and other browsers.', 'manifesto'),
				'required'	=> array('manifesto-opt-page-video', '=', true),
			),
			
			array(
                'id'        => 'manifesto-opt-page-hero-caption-title',
                'type'      => 'textarea',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
                'title'     => esc_html__('Hero Caption Title', 'manifesto'),
                'desc'  	=> esc_html__('The title displayed over hero section. Words or phrases separated with Enter will be automatically wrapped in a span element.', 'manifesto'),
	        ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-caption-subtitle',
                'type'      => 'textarea',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
                'title'     => esc_html__('Hero Caption Subtitle', 'manifesto'),
                'desc'  	=> esc_html__('Subtitle displayed over hero section, underneath the title. Words or phrases separated with Enter will be automatically wrapped in a span element.', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-page-hero-subtitle-left-padding',
                'type'      => 'select',
                'title'     => esc_html__('Indented Subtitle', 'manifesto'),
                'desc'      => esc_html__('Indent the hero subtitle by adding left padding.', 'manifesto'),
				'options'   => array(
                    'subtitle-padding-left'	=> esc_html__('Yes', 'manifesto'),
                    'subtitle-no-padding' => esc_html__('No', 'manifesto')
                ),
                'default'   => 'subtitle-no-padding'
            ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-scroll-caption',
                'type'      => 'text',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
				'title'     => esc_html__('Scroll Down Caption', 'manifesto'),
                'desc'  	=> esc_html__('Scroll down caption displayed to the bottom right of the hero image indicating scrolling down to reveal the content. Leave empty for no scroll down button.', 'manifesto'),
				'default'   => '',
	        ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-info-text',
                'type'      => 'text',
				'required'  => array( 'manifesto-opt-page-enable-hero', '=', true ),
                'title'     => esc_html__('Hero Info Text', 'manifesto'),
                'desc'  	=> esc_html__('Additional info regarding this page.', 'manifesto'),
	        ),
			
			array(
                'id'		=> 'manifesto-opt-page-hero-padding-bottom',
                'type'	=> 'select',
                'title'     => esc_html__('Enable bottom margin', 'manifesto'),
                'desc'      => esc_html__('Adds a bottom padding to the hero section separating it further from the page content below.', 'manifesto'),
				'options'   => array(
                    'enable-padding-bottom'	=> esc_html__('Yes', 'manifesto'),
                    'no-padding-bottom' => esc_html__('No', 'manifesto')
                ),
                'default'   => 'enable-padding-bottom'
            ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-parallax-caption',
                'type'      => 'select',
                'title'     => esc_html__('Enable Parallax Caption', 'manifesto'),
                'desc'      => esc_html__('Parallax scrolling effect on hero section title and subtitle. This only applies if there is no hero image assigned.', 'manifesto'),
				'options'   => array(
                    'parallax-scroll-caption'	=> esc_html__('Yes', 'manifesto'),
                    'normal-scroll-caption' => esc_html__('No', 'manifesto')
                ),
                'default'   => 'parallax-scroll-caption'
            ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-caption-align',
                'type'      => 'select',
                'title'     => esc_html__('Caption Alignment', 'manifesto'),
                'desc'      => esc_html__('The alignment of the hero caption (title and subtitle).', 'manifesto'),
				'options'   => array(
                    'text-align-center'	=> esc_html__('Center', 'manifesto'),
                    'text-align-left' => esc_html__('Left', 'manifesto')
                ),
                'default'   => 'text-align-left'
            ),
			
			array(
                'id'        => 'manifesto-opt-page-hero-caption-width',
                'type'      => 'select',
                'title'     => esc_html__('Caption Width', 'manifesto'),
                'desc'      => esc_html__('The type of the hero caption width.', 'manifesto'),
				'options'   => array(
                    'content-full-width'	=> esc_html__('Full', 'manifesto'),
                    'content-max-width' => esc_html__('Boxed', 'manifesto')
                ),
                'default'   => 'content-full-width'
            ),
			
			/**************************END - HERO SECTION OPTIONS**************************/
		),
	);
	
	$page_options[] = array(
        'title'         => esc_html__('Page Navigation', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-caret-right',
        'desc'          => esc_html__('Options concerning bottom page next navigation section.', 'manifesto'),
        'fields'        => array(

			/**************************PAGE NAVIGATION SECTION**************************/
			array(
                'id'        => 'manifesto-page-navigation-hover-caption',
                'type'      => 'text',
				'title'     => esc_html__('Navigation Hover Caption', 'manifesto'),
                'desc'		=> esc_html__('Caption displayed when hovering over bottom navigation section.', 'manifesto'),
				'default'   => esc_html__('Next Page', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-page-navigation-next-page',
                'type'      => 'select',
                'title'     => esc_html__('Next Page In Navigation', 'manifesto'),
				'desc'      => esc_html__('The next page navigation displayed at the bottom of the current page.', 'manifesto'),
                'options'   => manifesto_list_published_pages(),
				'default'   => '',
            ),
			
			array(
                'id'        => 'manifesto-opt-page-navigation-caption-title',
                'type'      => 'textarea',
                'title'     => esc_html__('Next Page Caption Title', 'manifesto'),
                'desc'  	=> esc_html__('Leave it empty to display the next page hero title. Words or phrases separated with Enter will be automatically wrapped in a span element.', 'manifesto'),
	        ),
			
			array(
                'id'        => 'manifesto-opt-page-navigation-caption-subtitle',
                'type'      => 'textarea',
                'title'     => esc_html__('Next Page Caption Subtitle', 'manifesto'),
                'desc'  	=> esc_html__('Leave it empty to display the next page hero subtitle. Words or phrases separated with Enter will be automatically wrapped in a span element.', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-page-navigation-caption-align',
                'type'      => 'select',
                'title'     => esc_html__('Next Page Caption Alignment', 'manifesto'),
                'desc'      => esc_html__('The alignment of the next page navigation caption.', 'manifesto'),
				'options'   => array(
                    'text-align-center'	=> esc_html__('Center', 'manifesto'),
                    'text-align-left' => esc_html__('Left', 'manifesto')
                ),
                'default'   => 'text-align-left'
            ),
			
			array(
                'id'        => 'manifesto-opt-page-navigation-caption-width',
                'type'      => 'select',
                'title'     => esc_html__('Next Page Caption Width', 'manifesto'),
                'desc'      => esc_html__('The next page navigation caption width.', 'manifesto'),
				'options'   => array(
                    'content-full-width'	=> esc_html__('Full', 'manifesto'),
                    'content-max-width' => esc_html__('Boxed', 'manifesto')
                ),
                'default'   => 'content-full-width'
            ),
			/**************************END - PAGE NAVIGATION SECTION**************************/
		),
	);
	
	$page_options[] = array(
        'title'         => esc_html__('All Portfolio Templates', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-folder-open',
        'desc'          => esc_html__('Options concerning only Portfolio templates (Creative Grid, Gallery, Carousel, List, Fullscreen).', 'manifesto'),
        'fields'        => array(

			array(
                'id'        	=> 'manifesto-opt-page-portfolio-filter-category',
                'type'      	=> 'text',
				'title'     	=> esc_html__('Category Filter', 'manifesto'),
                'desc'  		=> esc_html__('Paste here the portfolio category slugs you want to include in the portfolio page templates separated by comma. Do not include spaces. For example photography,branding. It will exclude the rest of the categories. The portfolio category slugs can be found in Portfolio -> Categories.', 'manifesto'),
				'default'  	=> '',
	        ),
						
			array(
				'id'        => 'manifesto-opt-page-portfolio-thumb-to-fullscreen',
				'type'      => 'select',
				'title'     => esc_html__('Thumbnail To Fullscreen Animation', 'manifesto'),
				'desc'      => esc_html__('Type of animation when navigating from a portfolio thumbnail to the portfolio hero section background image.', 'manifesto'),
				'options'   => array(
								'webgl-fitthumbs' 	=> esc_html__('WebGL Animation', 'manifesto'),
								'no-fitthumbs' => esc_html__('None', 'manifesto')
							),
				'default'   => 'webgl-fitthumbs',
			),
			
			array(
				'id'        => 'manifesto-opt-page-portfolio-thumb-to-fullscreen-webgl-type',
				'type'      => 'select',
				'title'     => esc_html__('WebGL Animation Type', 'manifesto'),
				'desc'      => esc_html__('Type of animation when WebGL thumbnail to fullscreen effect is selected.', 'manifesto'),
				'options'   => array(
								'fx-one' 	=> esc_html__('FX one', 'manifesto'),
								'fx-two' 	=> esc_html__('FX two', 'manifesto'),
								'fx-three' 	=> esc_html__('FX three', 'manifesto'),
								'fx-four' 	=> esc_html__('FX four', 'manifesto'),
								'fx-five' 	=> esc_html__('FX five', 'manifesto'),
								'fx-six' 		=> esc_html__('FX six', 'manifesto'),
								'fx-seven' => esc_html__('FX seven', 'manifesto')
							),
				'default'   => 'fx-one',
			),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-archive-caption',
                'type'      => 'text',
				'title'     => esc_html__('Archive Caption', 'manifesto'),
                'desc'		=> esc_html__('Caption of the link to the archive page.', 'manifesto'),
				'default'   => esc_html__('View Archive', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-archive-page',
                'type'      => 'select',
                'title'     => esc_html__('Archive Page', 'manifesto'),
				'desc'      => esc_html__('The link to the archive page, if defined, is displayed in Showcase Carousel, Showcase Slider and Infinity List. Usually it is a page defined with Showcase Gallery page template.', 'manifesto'),
                'options'   => manifesto_list_published_pages(),
				'default'   => '',
            ),
			
		),
	);

	$page_options[] = array(
        'title'         => esc_html__('Portfolio Showcase Grid', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-folder-open',
        'desc'          => esc_html__('Options concerning only Portfolio Showcase Grid template.', 'manifesto'),
        'fields'        => array(

			array(
				'id'        => 'manifesto-opt-page-portfolio-grid-layout-type',
				'type'      => 'select',
				'title'     => esc_html__('Grid Layout', 'manifesto'),
				'desc'      => esc_html__('Type of the grid layout.', 'manifesto'),
				'options'   => array(
								'layout-one' 	=> esc_html__('Opposite Grid', 'manifesto'),
								'layout-two' 	=> esc_html__('Spaced Thumbs Grid', 'manifesto'),
								'layout-three' 	=> esc_html__('Classic Thumbs Grid', 'manifesto')
							),
				'default'   => 'layout-one',
			),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-grid-enable-list-view',
                'type'      => 'switch',
                'title'     => esc_html__('Display List View Option', 'manifesto'),
                'desc'      => esc_html__('Displays the button switching grid and list views.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-grid-enable-shuffle-grid',
                'type'      => 'switch',
                'title'     => esc_html__('Display Shuffle Grid Button', 'manifesto'),
                'desc'      => esc_html__('The button that shuffles (rearranges) the current grid.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                 'id'       	=> 'manifesto-opt-page-portfolio-grid-content-position',
                 'type'     	=> 'select',
                 'title'    	=> esc_html__( 'Page Content Position', 'manifesto'),
                 'desc' 		=> esc_html__( 'Available only for Portfolio Grid Template: page content position in relation with portfolio grid.', 'manifesto'),
                 'options'   => array(
                    'after' 	=> esc_html__('After Portfolio Grid', 'manifesto'),
					'before'	=> esc_html__('Before Portfolio Grid', 'manifesto'),
                 ),
				 'default'	=> 'after',
            ),
			
		),
	);
	
	$page_options[] = array(
        'title'         => esc_html__('Portfolio Showcase Carousel', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-folder-open',
        'desc'          => esc_html__('Options concerning only Portfolio Showcase Carousel template.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-page-portfolio-carousel-enable-preview',
                'type'      => 'switch',
                'title'     => esc_html__('Enable Preview', 'manifesto'),
                'desc'      => esc_html__('Enables preview mode as extra step before navigating to individual portfolio page after clicking the carousel slide.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-carousel-enable-parallax',
                'type'      => 'switch',
                'title'     => esc_html__('Enable Parallax Effect', 'manifesto'),
                'desc'      => esc_html__('Enable parallax for carousel slides.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),			
		),
	);
	
	$page_options[] = array(
        'title'         => esc_html__('Portfolio Showcase Gallery', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-folder-open',
        'desc'          => esc_html__('Options concerning only Portfolio Showcase Gallery template.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-page-portfolio-gallery-enable-preview',
                'type'      => 'switch',
                'title'     => esc_html__('Enable Preview', 'manifesto'),
                'desc'      => esc_html__('Enables preview mode as extra step before navigating to individual portfolio page after clicking the gallery slide.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-gallery-enable-filters',
                'type'      => 'switch',
                'title'     => esc_html__('Display Filters', 'manifesto'),
                'desc'      => esc_html__('Displays category filters in the gallery page, allowing you dynamically switching between items categories.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-gallery-enable-tilt',
                'type'      => 'switch',
                'title'     => esc_html__('Enable tilt effect', 'manifesto'),
                'desc'      => esc_html__('Enables gallery tilt effect on mouse move.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-gallery-prev-page-caption',
                'type'      => 'text',
				'title'     => esc_html__('Close Archive Caption', 'manifesto'),
                'desc'		=> esc_html__('Caption of the link going back to the original page which started the current page as archive listing.', 'manifesto'),
				'default'   => esc_html__('Close Archive', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-page-portfolio-gallery-prev-page',
                'type'      => 'select',
                'title'     => esc_html__('Back To Page', 'manifesto'),
				'desc'      => esc_html__('The link to the original page, if defined, which started this page as archive listing. Usually in Showcase Fullscreen, Showcase Carousel and Infinity List templates.', 'manifesto'),
                'options'   => manifesto_list_published_pages(),
				'default'   => '',
            ),
		),
	);
	
	$page_options[] = array(
        'title'         => esc_html__('Portfolio Showcase Slider', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-folder-open',
        'desc'          => esc_html__('Options concerning only Portfolio Showcase Slider template.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-page-portfolio-slider-rotate-caption',
                'type'      => 'switch',
                'title'     => esc_html__('Rotate slide caption on transition?', 'manifesto'),
                'desc'      => esc_html__('Gives a rotate effect to the slide caption when navigating to the next. Otherwise the caption will change with a linear effect.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => false
            )
		),
	);
	
	$metaboxes[] = array(
        'id'            => 'clapat_' . MANIFESTO_THEME_ID . '_page_options',
        'title'         => esc_html__( 'Page Options', 'manifesto'),
        'post_types'    => array( 'page' ),
        'position'      => 'normal', // normal, advanced, side
        'priority'      => 'high', // high, core, default, low
        'sidebar'       => false, // enable/disable the sidsebar in the normal/advanced positions
        'sections'      => $page_options,
    );

    $blog_post_options = array();
    $blog_post_options[] = array(

        'title'         => esc_html__('General', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-wrench',
        'desc'          => esc_html__('Options concerning blog post options.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-blog-bknd-color-code',
                'type'      => 'color-picker',
                'title'     => esc_html__('Background color', 'manifesto'),
				'desc'      => esc_html__('Background color for this blog post.', 'manifesto'),
                'default'   => '#0c0c0c',
            ),
			
			array(
                'id'        => 'manifesto-opt-blog-bknd-color',
                'type'      => 'select',
                'title'     => esc_html__('Background type', 'manifesto'),
				'desc'      => esc_html__('Background type for this blog post.', 'manifesto'),
                'options'   => array(
                    'dark-content' 	=> esc_html__('Light', 'manifesto'),
                    'light-content' => esc_html__('Dark', 'manifesto')

                ),
				'default'   => 'light-content',
            ),

			array(
                 'id'       	=> 'manifesto-opt-blog-hero-caption-alignment',
                 'type'     	=> 'select',
                 'title'    	=> esc_html__( 'Header Caption Alignment', 'manifesto'),
                 'desc' 		=> esc_html__( 'The alignment of the blog post caption.', 'manifesto'),
                 'options'   => array(
                    'text-align-left' 	=> esc_html__('Left', 'manifesto'),
					'text-align-center'	=> esc_html__('Center', 'manifesto'),
                 ),
				 'default'	=> 'text-align-left',
            ),
          )
        );

	$blog_post_options[] = array(
		'title'         => esc_html__('', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-wrench',
		'desc'          => '',
        'fields'        => array()
		);
		
    $metaboxes[] = array(
       'id'            => 'clapat_' . MANIFESTO_THEME_ID . '_post_options',
       'title'         => esc_html__( 'Post Options', 'manifesto'),
       'post_types'    => array( 'post' ),
       'position'      => 'normal', // normal, advanced, side
       'priority'      => 'high', // high, core, default, low
       'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
       'sections'      => $blog_post_options,
    );


    $portfolio_options = array();
	$portfolio_options[] = array(
		'title'         => esc_html__('General', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-icon-wrench',
        'desc'          => esc_html__('Options concerning portfolio item options.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-portfolio-bknd-color-code',
                'type'      => 'color-picker',
                'title'     => esc_html__('Background color', 'manifesto'),
				'desc'      => esc_html__('Background color for this portfolio item page.', 'manifesto'),
                'default'   => '#0c0c0c',
            ),
			
			array(
                'id'        => 'manifesto-opt-portfolio-bknd-color',
                'type'      => 'select',
                'title'     => esc_html__('Background type', 'manifesto'),
				'desc'      => esc_html__('Background type for this portfolio item page.', 'manifesto'),
                'options'   => array(
                    'dark-content' 	=> esc_html__('Light', 'manifesto'),
                    'light-content' => esc_html__('Dark', 'manifesto')

                ),
				'default'   => 'light-content',
            ),
			
			array(
				'id'        => 'manifesto-opt-portfolio-project-year',
				'type'      => 'text',
				'title'     => esc_html__('Project Year', 'manifesto'),
				'desc'   	=> esc_html__('Year the portfolio project was implemented. Displayed in Parallax Panels, Showcase Grid and Archive List portfolio page templates.', 'manifesto'),
				'default'	=> date("Y")
			),

			array(
				'id'        => 'manifesto-opt-portfolio-view-all-projects-url',
				'type'      => 'text',
				'title'     => esc_html__('View All Projects URL', 'manifesto'),
				'desc'   	=> esc_html__('This a an URL to a main projects page. It is displayed at the bottom of the portfolio project page, just above the next project navigation section. Leave empty for none.', 'manifesto'),
				'default'	=> ""
			),
			
			array(
				'id'        => 'manifesto-opt-portfolio-view-all-projects-caption',
				'type'      => 'text',
				'title'     => esc_html__('View All Projects Caption', 'manifesto'),
				'desc'   	=> esc_html__('Caption of the main projects page URL.', 'manifesto'),
				'default' => esc_html__('View All Projects', 'manifesto'),
			),
        ),
    );
	
	$portfolio_options[] = array(
        'title'         => esc_html__('Hero Section', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-website',
        'desc'          => esc_html__('Options concerning Hero top section in individual portfolio pages.', 'manifesto'),
        'fields'        => array(

			/**************************HERO SECTION OPTIONS**************************/
			array(
				'id'        => 'manifesto-opt-portfolio-hero-img',
                'type'      => 'media',
                'url'       => true,
                'title'     => esc_html__('Hero Image', 'manifesto'),
                'desc'      => esc_html__('Upload hero background image. The hero image is the fullscreen image in hero section. Hero section is the header section displayed at the top of the individual project page.', 'manifesto'),
                'default'   => array(),
            ),
			
			array(
				'id'        => 'manifesto-opt-portfolio-video',
				'type'      => 'switch',
				'title'     => esc_html__('Video Hero', 'manifesto'),
				'desc'   	=> esc_html__('Video displayed as hero section in project page. If you check this option set the Hero Image as the first frame image of the video to avoid flickering!', 'manifesto'),
				'on'       	=> esc_html__('Yes', 'manifesto'),
				'off'      	=> esc_html__('No', 'manifesto'),
				'default'   => false
			),

			array(
				'id'        => 'manifesto-opt-portfolio-video-webm',
				'type'      => 'text',
				'title'     => esc_html__('Webm Video URL', 'manifesto'),
				'desc'   	=> esc_html__('URL of the hero section background webm video. Webm format is previewed in Chrome and Firefox.', 'manifesto'),
				'required'	=> array('manifesto-opt-portfolio-video', '=', true),
			),

			array(
				'id'        => 'manifesto-opt-portfolio-video-mp4',
				'type'      => 'text',
				'title'     => esc_html__('MP4 Video URL', 'manifesto'),
				'desc'   	=> esc_html__('URL of the hero section background MP4 video. MP4 format is previewed in IE, Safari and other browsers.', 'manifesto'),
				'required'	=> array('manifesto-opt-portfolio-video', '=', true),
			),

			array(
				'id'        => 'manifesto-opt-portfolio-hero-caption-title',
				'type'      => 'textarea',
				'title'     => esc_html__('Hero Caption Title', 'manifesto'),
				'desc'  	=> esc_html__('Title displayed over hero section. The hero background image is set in the hero image set in preceding option. Words or phrases separated with Enter will be automatically wrapped in a span element.', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-portfolio-hero-caption-subtitle',
                'type'      => 'textarea',
                'title'     => esc_html__('Hero Caption Subtitle', 'manifesto'),
                'desc'  	=> esc_html__('Subtitle displayed on Thumbnail Preview Mode below the title.', 'manifesto'),
			),
			
			array(
                'id'        => 'manifesto-opt-portfolio-hero-info-text',
                'type'      => 'textarea',
                'title'     => esc_html__('Hero Info Text', 'manifesto'),
                'desc'  	=> esc_html__('Additional information about the project displayed underneath title and subtitle.', 'manifesto'),
			),
									
			array(
                'id'        => 'manifesto-opt-portfolio-hero-parallax-caption',
                'type'      => 'select',
                'title'     => esc_html__('Enable Parallax Caption', 'manifesto'),
                'desc'      => esc_html__('Parallax scrolling effect on hero section title and subtitle. This only applies if there is no hero image assigned.', 'manifesto'),
				'options'   => array(
                    'parallax-scroll-caption'	=> esc_html__('Yes', 'manifesto'),
                    'normal-scroll-caption' => esc_html__('No', 'manifesto')
                ),
                'default'   => 'parallax-scroll-caption'
            ),
			
			array(
                'id'        => 'manifesto-opt-portfolio-hero-scroll-caption',
                'type'      => 'text',
				'title'     => esc_html__('Scroll Down Caption', 'manifesto'),
                'desc'  => esc_html__('Scroll down caption displayed to the left of the hero image indicating scrolling down to reveal the content. Leave empty for no scroll down button.', 'manifesto'),
				'default'   => '',
	        ),
			/**************************END - HERO SECTION OPTIONS**************************/

		),
	);
	
	$portfolio_options[] = array(
        'title'         => esc_html__('Showcase Gallery', 'manifesto'),
        'icon_class'    => 'icon-large',
        'icon'          => 'el-puzzle',
        'desc'          => esc_html__('Options concerning portfolio item thumbnails in showcase gallery page template.', 'manifesto'),
        'fields'        => array(

			array(
                'id'        => 'manifesto-opt-portfolio-thumb-gallery-offset',
                'type'      => 'select',
                'title'     => esc_html__('Gallery Thumbnail Offset', 'manifesto'),
                'desc'      => esc_html__('The x axis offset (horizontally) in Showcase Gallery template. How far from the left margin of the page the thumbnail is positioned.', 'manifesto'),
				'options'   => array(
                    's0' => '0',
                    's25' => '25',
					's50' => '50',
					's75' => '75',
					's100' => '100'
                ),
                'default'   => 's0'
            ),
			
			array(
                'id'        => 'manifesto-opt-portfolio-thumb-gallery-scale',
                'type'      => 'select',
                'title'     => esc_html__('Gallery Thumbnail Scale', 'manifesto'),
                'desc'      => esc_html__('The thumbnail scale in Showcase Gallery template. How big the thumbnail is.', 'manifesto'),
				'options'   => array(
                    'has-scale-small'	=> esc_html__('Small', 'manifesto'),
                    'has-scale-medium' => esc_html__('Medium', 'manifesto'),
					'has-scale-large' => esc_html__('Large', 'manifesto')
                ),
                'default'   => 'has-scale-large'
            ),
			
			array(
                'id'        => 'manifesto-opt-portfolio-gallery-enable-parallax',
                'type'      => 'switch',
                'title'     => esc_html__('Enable Parallax Effect', 'manifesto'),
                'desc'      => esc_html__('Enable parallax for gallery slides.', 'manifesto'),
				'on'       => esc_html__('Yes', 'manifesto'),
				'off'      => esc_html__('No', 'manifesto'),
                'default'   => true
            ),

		),
	);
	
    $metaboxes[] = array(
        'id'            => 'clapat_' . MANIFESTO_THEME_ID . '_portfolio_options',
        'title'         => esc_html__( 'Portfolio Item Options', 'manifesto'),
        'post_types'    => array( 'manifesto_portfolio' ),
        'position'      => 'normal', // normal, advanced, side
        'priority'      => 'high', // high, core, default, low
        'sidebar'       => false, // enable/disable the sidebar in the normal/advanced positions
        'sections'      => $portfolio_options,
    );

	return $metaboxes;
  }

}

if( class_exists('Manifesto\Core\Metaboxes\Meta_Boxes') ){

	$metabox_definitions = array();
	$metabox_definitions = manifesto_add_metaboxes( $metabox_definitions );
	do_action( 'manifesto/core/add_metaboxes', $metabox_definitions );
}
