<?php

if( !function_exists('manifesto_render_footer_social_links' ) )
{
	function manifesto_render_footer_social_links(){

		global $manifesto_social_links_icons;
		$manifesto_social_links = "";
		for( $idx = 1; $idx <= MANIFESTO_MAX_SOCIAL_LINKS; $idx++ ){

			$social_name = manifesto_get_theme_options( 'clapat_manifesto_footer_social_' . $idx );
			$social_url  = manifesto_get_theme_options( 'clapat_manifesto_footer_social_url_' . $idx );

			if( $social_url ){

				if( manifesto_get_theme_options( 'clapat_manifesto_social_links_icons' ) ){
					
					$manifesto_social_links .= '<li><span class="parallax-wrap"><a class="parallax-element" href="' . esc_url( $social_url ) . '" target="_blank"><i class="fa-brands fa-'. esc_attr( $manifesto_social_links_icons[ $social_name ] ) . '"></i></a></span></li>';
				}
				else {
					
					$manifesto_social_links .= '<li><span class="parallax-wrap"><a class="parallax-element" href="' . esc_url( $social_url ) . '" target="_blank">' . wp_kses( $social_name, 'manifesto_allowed_html' ) . '</a></span></li>';
				}

			}

		}
		
		if( !empty( $manifesto_social_links ) ){
?>
						<div class="socials-wrap">
							<div class="socials-icon"><i class="fa-solid fa-share-nodes"></i></div>
							<div class="socials-text"><?php echo wp_kses( manifesto_get_theme_options( 'clapat_manifesto_footer_social_links_prefix' ), 'manifesto_allowed_html' ); ?></div>
							<ul class="socials">
								<?php echo wp_kses( $manifesto_social_links, 'manifesto_allowed_html' ); ?>
							</ul>
						</div>
<?php			
		
		}

	}
}

manifesto_render_footer_social_links();

?>
