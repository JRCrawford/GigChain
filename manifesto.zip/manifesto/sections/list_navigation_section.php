<?php
						$manifesto_next_page_archive_id	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-archive-page' );
						$manifesto_page_nav_enable			= !empty( $manifesto_next_page_archive_id );
						$manifesto_archive_page_url 	 		= get_permalink( $manifesto_next_page_archive_id );
						$manifesto_page_archive_caption		= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-portfolio-archive-caption' );
						
						if( $manifesto_page_nav_enable ){
?>
						<a class="ajax-link link-text" data-type="page-transition" href="<?php echo esc_url( $manifesto_archive_page_url ); ?>">
							<span class="link" data-hover="<?php echo esc_attr( $manifesto_page_archive_caption	 ); ?>"><?php echo wp_kses( $manifesto_page_archive_caption, 'manifesto_allowed_html' ); ?></span>
						</a>
<?php 				} ?>
						<div class="progress-info fadeout-element">
							<div class="progress-info-fill"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_showcase_scroll_drag_caption'), 'manifesto_allowed_html') ?></div>
							<div class="progress-info-fill-2"><?php echo wp_kses( manifesto_get_theme_options('clapat_manifesto_showcase_scroll_drag_caption'), 'manifesto_allowed_html') ?></div>
						</div>