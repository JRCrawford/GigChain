<?php
/**
 * Created by Clapat.
 * Date: 14/07/23
 * Time: 11:33 AM
 */

// hero section container properties
$manifesto_hero_properties = new Manifesto_Hero_Properties();
$manifesto_hero_properties->getProperties( get_post_type() );

if( $manifesto_hero_properties->enabled ){

	get_template_part('sections/hero_section_container');
}
else {
	
	$manifesto_hero_styles = $manifesto_hero_properties->width . " " . $manifesto_hero_properties->scroll_position . " " . $manifesto_hero_properties->alignment . " " . $manifesto_hero_properties->bottom_padding;
	
?>
		<!-- Hero Section -->
		<div id="hero" <?php if( !manifesto_get_theme_options( 'clapat_manifesto_enable_page_title_as_hero' ) ){ echo 'class="hero-hidden"'; } ?>>
			<div id="hero-styles">
				<div id="hero-caption" class="<?php echo esc_attr( $manifesto_hero_styles ); ?>">
					<div class="inner">
						<h1 class="hero-title caption-timeline"><span><?php the_title(); ?></span></h1>
					</div>
				</div>
			</div>
		</div>
		<!--/Hero Section -->   
		
<?php

}

?>
