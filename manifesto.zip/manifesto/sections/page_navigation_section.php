 <?php

	$manifesto_next_page_nav_id				= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-navigation-next-page' );
	$manifesto_page_nav_enable				= !empty( $manifesto_next_page_nav_id );
	$manifesto_page_hover_caption			= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-page-navigation-hover-caption' );
	$manifesto_next_page_caption_width	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-navigation-caption-width' );
	$manifesto_next_page_caption_align	= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-navigation-caption-align' );
	
	$manifesto_next_url	 = get_permalink( $manifesto_next_page_nav_id );
	
	$manifesto_hero_properties 			= new Manifesto_Hero_Properties();
	$manifesto_hero_properties->post_id	= $manifesto_next_page_nav_id;
	$manifesto_hero_properties->getProperties( get_post_type( $manifesto_next_page_nav_id ) );
	$manifesto_next_hero_title				= $manifesto_hero_properties->caption_title;
	$manifesto_next_hero_subtitle			= $manifesto_hero_properties->caption_subtitle;
	if( !$manifesto_hero_properties->enabled ){
		
		$manifesto_next_hero_title 			= '<span>' . get_the_title( $manifesto_next_page_nav_id ) . '</span>';
		$manifesto_next_hero_subtitle		= "";
	}
	$manifesto_url_class = "next-ajax-link-page";
	if( !$manifesto_hero_properties->enabled && !manifesto_get_theme_options( 'clapat_manifesto_enable_page_title_as_hero' ) ){
		
		// This is a page without hero section so a seamless AJAX transition is not possible
		$manifesto_url_class = "ajax-link";
	}
	
	// Get the next page title & subtitle captions; if they are empty use the hero section of the next page
	$manifesto_page_caption_title			= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-navigation-caption-title' );
	if( empty( $manifesto_page_caption_title ) ){
		
		$manifesto_page_caption_title = $manifesto_next_hero_title;
	}
	else {
		
		$title_row	= $manifesto_page_caption_title;
		$title_list	= preg_split('/\r\n|\r|\n/', $title_row);
		$manifesto_page_caption_title	= "";
		foreach( $title_list as $title_bit ){
					
			$manifesto_page_caption_title .= '<span>' . $title_bit . '</span>';
		}
	}
	
	$manifesto_page_caption_subtitle		= manifesto_get_post_meta( MANIFESTO_THEME_OPTIONS, get_the_ID(), 'manifesto-opt-page-navigation-caption-subtitle' );
	if( empty( $manifesto_page_caption_subtitle ) ){
		
		$manifesto_page_caption_subtitle = $manifesto_next_hero_subtitle;
	}
	else {
		
		$title_row	= $manifesto_page_caption_subtitle;
		$title_list	= preg_split('/\r\n|\r|\n/', $title_row);
		$manifesto_page_caption_subtitle	= "";
		foreach( $title_list as $title_bit ){
					
			$manifesto_page_caption_subtitle .= '<span>' . $title_bit . '</span>';
		}
	}

	if( $manifesto_page_nav_enable ){
?>
				<!-- Page Navigation --> 
				<div id="page-nav">
					<div class="page-nav-wrap">
						<div class="page-nav-caption <?php echo esc_attr( $manifesto_next_page_caption_width ); ?> <?php echo esc_attr( $manifesto_next_page_caption_align ); ?>">
							<div class="inner">
								<a class="page-title <?php echo esc_attr( $manifesto_url_class ); ?>" href="<?php echo esc_url( $manifesto_next_url ); ?>" data-type="page-transition" data-centerline="<?php echo esc_attr( $manifesto_page_hover_caption ); ?>">
									<div class="next-hero-title primary-font-title caption-timeline"><?php echo wp_kses( $manifesto_page_caption_title, 'manifesto_allowed_html' ); ?></div>
								</a>
								<?php if( !empty( $manifesto_page_caption_subtitle ) ){ ?>
								<div class="next-hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_page_caption_subtitle, 'manifesto_allowed_html' ); ?></div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
				<!--/Page Navigation -->
<?php } ?>
