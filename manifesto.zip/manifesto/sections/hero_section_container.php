<?php
/**
 * Created by Clapat.
 * Date: 14/07/23
 * Time: 1:34 PM
 */
$manifesto_hero_properties = new Manifesto_Hero_Properties();
$manifesto_hero_properties->getProperties( get_post_type() );

$hero_styles = $manifesto_hero_properties->width;

if( !empty( $manifesto_hero_properties->alignment ) ){
	
	$hero_styles .= " " . $manifesto_hero_properties->alignment;
}
if( !empty( $manifesto_hero_properties->scroll_position ) ){
	
	$hero_styles .= " " . $manifesto_hero_properties->scroll_position;
}
if( !empty( $manifesto_hero_properties->subtitle_indent ) ){
	
	$hero_styles .= " " . $manifesto_hero_properties->subtitle_indent;
}
if( !empty( $manifesto_hero_properties->bottom_padding ) ){
	
	$hero_styles .= " " . $manifesto_hero_properties->bottom_padding;
}

if( $manifesto_hero_properties->enabled ){

?>

		<?php if( $manifesto_hero_properties->image && !empty( $manifesto_hero_properties->image['url'] ) ){ ?>
		<!-- Hero Section -->
		<div id="hero" class="has-image<?php if( manifesto_get_theme_options( 'clapat_manifesto_portfolio_autoscroll_hero' ) ){ echo " autoscroll"; } ?>">
			<div id="hero-styles">
				<div id="hero-caption" class="<?php echo esc_attr( $hero_styles ); ?>">
					<div class="inner">
						<h1 class="hero-title caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_title, 'manifesto_allowed_html' ); ?></h1>
						<?php if( !empty( $manifesto_hero_properties->caption_subtitle ) && !is_singular( 'manifesto_portfolio' ) ){ ?>
						<div class="hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_subtitle, 'manifesto_allowed_html' ); ?></div>
						<?php } ?>
						<div class="hero-arrow link caption-timeline"><span><i class="arrow-icon"></span></i></div>
					</div>
				</div>
				<?php if( !empty( $manifesto_hero_properties->info_text ) ){ ?>
				<div id="hero-description" class="content-max-width">
					<div class="inner">
						<?php echo wp_kses( $manifesto_hero_properties->info_text, 'manifesto_allowed_html' ); ?>
					</div>
				</div>
				<?php }	else {
					
					if( is_singular( 'manifesto_portfolio' ) ){
				?>
				<div id="hero-description" class="description-empty content-max-width text-align-center"></div>
				<?php
					}
				}
				?>
				<div id="hero-footer">
					<div class="hero-footer-left">
						<div class="button-wrap right scroll-down">
							<div class="icon-wrap parallax-wrap">
								<div class="button-icon parallax-element">
									<i class="arrow-icon-down"></i>
								</div>
							</div>
							<?php if( $manifesto_hero_properties->scroll_down_caption ){ ?>
							<div class="button-text sticky right">
								<span data-hover="<?php echo esc_attr( $manifesto_hero_properties->scroll_down_caption ); ?>"><?php echo wp_kses( $manifesto_hero_properties->scroll_down_caption, 'manifesto_allowed_html' ); ?></span>
							</div>
							<?php } ?>
						</div>	
                     </div>
					<?php if( $manifesto_hero_properties->share ){ ?>
					<div class="hero-footer-right">
						<div id="share" class="page-action-content" data-text="<?php echo esc_attr( manifesto_get_theme_options( 'clapat_manifesto_portfolio_share_social_networks_caption' ) ); ?>"></div>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<div id="hero-image-wrapper">
			<div id="hero-background-layer" class="parallax-scroll-image">
				<div id="hero-bg-image" style="background-image:url(<?php echo esc_url( $manifesto_hero_properties->image['url'] ); ?>)">
				<?php if( $manifesto_hero_properties->video ){ ?>
					<div class="hero-video-wrapper">
						<video loop muted playsinline class="bgvid">
						<?php if( !empty( $manifesto_hero_properties->video_mp4 ) ){ ?>
							<source src="<?php echo esc_url( $manifesto_hero_properties->video_mp4 ); ?>" type="video/mp4">
						<?php } ?>
						<?php if( !empty( $manifesto_hero_properties->video_webm ) ){ ?>
							<source src="<?php echo esc_url( $manifesto_hero_properties->video_webm ); ?>" type="video/webm">
						<?php } ?>
						</video>
					</div>
				<?php } ?>
				</div>
			</div>
		</div>
		<!--/Hero Section -->
		<?php } else { ?>

		<!-- Hero Section -->
		<div id="hero">
			<div id="hero-styles">
				<div id="hero-caption" class="<?php echo esc_attr( $hero_styles ); ?>">
					<div class="inner">
						<h1 class="hero-title caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_title, 'manifesto_allowed_html' ); ?></h1>
						<?php if( !empty( $manifesto_hero_properties->caption_subtitle ) && !is_singular( 'manifesto_portfolio' ) ){ ?>
						<div class="hero-subtitle caption-timeline"><?php echo wp_kses( $manifesto_hero_properties->caption_subtitle, 'manifesto_allowed_html' ); ?></div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
		<!--/Hero Section -->
		<?php } ?>

<?php
}
?>
